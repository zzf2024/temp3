# QComp PPL Optimization Guidance

## 1. Project Goal

The final acceptance target:

After AWQ quantization, apply QComp compensation and achieve:

- PPL improvement >= 2% compared with AWQ baseline
- throughput retention >= 85%

Acceptance:

```
P_comp < P_awq

(P_awq - P_comp) / P_awq >= 0.02
```

The optimization target is the final PPL, not only activation reconstruction error.

---

## 2. Current Status

Existing pipeline contains:

- AWQ quantization
- QComp low-rank adapter
- single-layer QComp
- multi-layer QComp
- layer scoring
- alpha search
- benchmark
- acceptance report

QComp formulation:

```
Y_awq = X W_awq^T

Y_fp = X W_fp^T

DeltaY = Y_fp - Y_awq

DeltaY ≈ X B^T A^T
```

Runtime:

```
output = awq_output + alpha * QComp(x)
```

---

## 3. Main Problem Diagnosis

Current failure:

Calibration reconstruction improves,
but PPL does not improve.

Root cause:

```
calibration distribution != evaluation distribution
```

The adapter learns calibration-specific correction and hurts generalization.

---

# Optimization Priority

## Step 1: Match calibration distribution with evaluation distribution

Use evaluation dataset distribution for calibration.

Recommended:

```
eval.jsonl

split:

80% calibration
20% validation

build adapter

remaining data:
final evaluation
```

Calibration path must be configurable.

---

## Step 2: Increase calibration token amount

Current calibration amount is insufficient.

Support:

```
--max-texts 512
```

or larger.

Important:

Collect token-level activations.

A text with 100 tokens should generate around 100 activation samples.

---

## Step 3: Add ridge lambda search

Make ridge regularization configurable.

Search:

```
1e-3
1e-2
1e-1
1
```

Expose CLI parameter:

```
--ridge-lambda
```

Save lambda in adapter configuration.

---

## Step 4: Layer search

Test:

```
model.layers.0.mlp.down_proj
model.layers.1.mlp.down_proj
model.layers.2.mlp.down_proj
model.layers.3.mlp.down_proj
```

Selection criterion:

Use final PPL.

Do not select only by output reconstruction error.

---

## Step 5: PPL-based alpha search

Current alpha optimization uses output error.

Add optional PPL-based search:

For each alpha:

```
attach adapter
evaluate PPL
choose minimum PPL
```

Candidate:

```
0.05
0.1
0.2
0.5
0.75
1.0
```

---

## Step 6: Multi-layer search

After single-layer success:

Test:

Layers:

```
1
2
4
8
```

Ranks:

```
2
4
8
```

Selection based on PPL.

---

# Required Experiments

## Experiment A

Layer:

```
model.layers.0.mlp.down_proj
```

Parameters:

```
rank=4
lambda=0.1
calibration=eval split
```

---

## Experiment B

Layer:

```
model.layers.0.mlp.down_proj
```

Parameters:

```
rank=8
lambda=0.1
```

---

## Experiment C

Layer:

```
model.layers.1.mlp.down_proj
```

Same settings.

---

## Experiment D

Multi-layer:

```
layers=0,1
rank=4
```

---

# Logging Requirement

Save:

```
results/qcomp_search.csv
```

Format:

```
layer,rank,lambda,alpha,PPL,PPL_delta
```

Example:

```
layer0,4,0.1,0.5,21.10,-2.03%
```

---

# Acceptance Check

AWQ:

```
21.5365
```

Target:

```
QComp PPL <= 21.1058
```

---

# Things NOT to do

Do NOT:

1. Increase rank blindly.

2. Optimize only activation error.

3. Change QComp mathematical formulation before fixing data issues.

4. Add complicated methods before solving calibration distribution mismatch.

---

# Expected Successful Path

```
eval-distribution calibration
        |
        v
larger token samples
        |
        v
ridge lambda tuning
        |
        v
layer0/layer1 search
        |
        v
PPL-based alpha search
        |
        v
multi-layer combination
```

Goal:

```
AWQ PPL = 21.5365

QComp PPL <= 21.1
```
