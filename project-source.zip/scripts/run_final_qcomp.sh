#!/usr/bin/env bash
set -euo pipefail

# QComp Final Reproduction Script
# Reproduces: AWQ baseline + QComp top40 adapter PPL and benchmark
# Config: configs/final_qcomp.yaml (see for frozen parameters)
# Uses configs/mvp_qwen.yaml for CLI (generates correct run_id for existing AWQ checkpoint)

echo "========================================"
echo " QComp Final Reproduction"
echo "========================================"

# Restore GPU device nodes if needed
if ! python3 -c "import torch; assert torch.cuda.is_available()" 2>/dev/null; then
    echo "GPU not available, restoring device nodes..."
    bash restore_gpu.sh
fi

export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1

CONFIG="configs/mvp_qwen.yaml"
ADAPTER="artifacts/final/qcomp_top40_r8_lam0p1"
EVAL_PATH="data/eval.jsonl"
ALPHA="0.35"

echo ""
echo "[1/4] Benchmarking AWQ baseline..."
python3 -m a10_quant_comp.cli benchmark-awq --config "$CONFIG" --overwrite

echo ""
echo "[2/4] Evaluating AWQ baseline PPL..."
python3 -m a10_quant_comp.cli eval-awq-ppl --config "$CONFIG" --overwrite

echo ""
echo "[3/4] Evaluating AWQ+QComp PPL (alpha=$ALPHA)..."
python3 -m a10_quant_comp.cli eval-qcomp-ppl --config "$CONFIG" \
    --adapter "$ADAPTER" --alpha-override "$ALPHA" --eval-path "$EVAL_PATH" --overwrite

echo ""
echo "[4/4] Benchmarking AWQ+QComp throughput..."
python3 -m a10_quant_comp.cli benchmark-qcomp --config "$CONFIG" \
    --adapter "$ADAPTER" --overwrite

echo ""
echo "========================================"
echo " Reproduction Complete"
echo "========================================"
echo "Results saved to artifacts/c5fc6a81f2f7/results/"
echo ""
echo "Expected results:"
echo "  AWQ PPL:       21.5365"
echo "  QComp PPL:     21.0379 (-2.32%)"
echo "  Throughput:    92.7% retention"
