## 一、概述

这是一个 Ubuntu 24.04.3 开发环境模板，提供了基础的开发工具和工具链。

该模板内置了常用的开发工具，包括 GCC 编译器集合、GDB 调试工具以及 clang-tidy 代码检查工具，可以支持多种编程语言的开发需求。

## 二、快速开始

### 环境准备

确保已安装必要的开发工具：

```bash
# 检查 g++ 版本
g++ --version

# 如未安装，可使用以下命令安装
sudo apt update
sudo apt install build-essential gdb clang-tidy
```

### 编译和运行

本环境支持多种编程语言的开发。例如，使用 GCC 编译 C/C++ 程序：

```bash
g++ main.cpp -o main && ./main
```

- **`g++ main.cpp -o main`**：
  - `g++` 是 GNU 编译器集合（GCC）中的编译器，用于将源代码文件编译成可执行文件。
  - `main.cpp` 待编译的源文件。
  - `-o main` 用来指定输出文件的名称，不指定名称默认生成 a.out。
- **`./main`**：
  - `./main` 执行编译后的可执行文件。

### 其他编译选项

```bash
# 启用调试信息
g++ -g main.cpp -o main

# 启用所有警告
g++ -Wall -Wextra main.cpp -o main

# 指定语言标准
g++ -std=c++17 main.cpp -o main
```

**关于构建工具**

本环境默认安装了 GNU 编译器集合（GCC），可以满足基础的 C++ 代码编译需求。如果需要使用其他构建工具（如 CMake、Make），可以使用以下命令安装：

```bash
# 安装 CMake
sudo apt install cmake

# 安装 Make（通常已随 build-essential 安装）
sudo apt install make
```

## 三、文件结构

```
workspace/
├── .clang-tidy       // Clang-Tidy 代码检查工具的配置文件
├── main.cpp          // 主源文件
├── README.md         // 项目说明文档
└── img               // 图片目录
    └── qr-code.png   // 二维码图片
```

## 四、开发文档与资源

- [GCC 官方文档](https://gcc.gnu.org/)
- [clang-tidy 文档](https://clang.llvm.org/extra/clang-tidy/)
- [Ubuntu GCC 安装指南](https://ubuntu.com/tutorials/basic-compilation-and-installation-with-gcc#2-installing-gcc)
- [cppreference.com - C/C++ 参考文档](https://en.cppreference.com/w/)

## 五、帮助和支持

### 1. 相关支持
- [Ubuntu 官方文档](https://ubuntu.com/server/docs)
- [GCC 官方文档](https://gcc.gnu.org/onlinedocs/)
- [nosleep 空间不休眠脚本使用方法](nosleep.md)

### 2. 在线学习资源
- [Linux 命令行教程](https://linuxjourney.com/)
- [Linux 基础知识](https://linuxjourney.com/lesson/the-shell)



