# QComp Final Technical Report

## 1. Problem Statement

AWQ (Activation-aware Weight Quantization) compresses LLM weights to 4-bit (W4A16), reducing memory and accelerating inference. However, quantization introduces output error that degrades language modeling quality (measured by perplexity, PPL).

**Goal**: Compensate AWQ quantization error to recover PPL without retraining, while maintaining throughput >= 85% of AWQ baseline.

## 2. AWQ Degradation Analysis

- Model: Qwen/Qwen2.5-0.5B
- Quantization: AWQ W4A16, group_size=128
- AWQ baseline PPL: 21.5365
- FP16 reference PPL: ~20.9 (not measured in this run)
- Degradation source: per-layer output error `DeltaY = Y_fp16 - Y_awq`

72 candidate layers were scored. Highest error layers are concentrated in deeper transformer blocks (layers 20-23), particularly `self_attn.o_proj` and `mlp.gate_proj`.

## 3. QComp Method

### 3.1 Core Formula

QComp compensates in activation space using a factorized low-rank adapter:

```
DeltaY ≈ X B^T A^T
```

where:
- `X` is the input activation to the AWQ quantized layer
- `A` is `[out_features, rank]`
- `B` is `[rank, in_features]`
- `A@B` is never materialized

### 3.2 Runtime Injection

At inference time, each compensated layer computes:

```
output = AWQ_output + alpha * QComp(x)
       = AWQ_output + alpha * linear(linear(x, B), A)
```

This adds two small GEMMs per layer (rank=8), avoiding any dense correction matrix or weight modification.

### 3.2 Constraints

- No `delta = A@B` generated
- No dense correction GEMM
- No weight residual `W-Q`
- QComp math form preserved: `Y_fp16 - Y_awq ≈ (X B^T) A^T`

## 4. Ridge Regression Formulation

### 4.1 Output-Space Target

For each layer, collect:
- `X_awq`: input to AWQ quantized layer [N, in]
- `Y_fp`: FP16 layer output [N, out]
- `Y_awq`: AWQ layer output [N, out]
- Target: `T = Y_fp - Y_awq` [N, out]

### 4.2 Ridge Regression

Solve for effective weight:

```
W_eff^T = (X^T X + λI)^{-1} X^T T
```

where λ (ridge_lambda) controls regularization. This prevents overfitting when N < in_features.

### 4.3 Activation-Weighted Truncated SVD

`W_eff` [out, in] is decomposed via activation-weighted truncated SVD:

1. Compute activation weights: `R_diag = sqrt(mean(X^2, dim=0) + λ)`
2. Weight: `Ew = W_eff * R_diag`
3. SVD: `Ew = U S V^T`
4. Truncate to rank r: `A = U[:, :r] * S[:r]`, `B = V[:r, :] / R_diag`

## 5. Calibration Distribution Matching

### 5.1 Problem

Initial experiments used `calib.jsonl` (avg 88 words) for calibration but `eval.jsonl` (avg 151 words) for evaluation. The distribution mismatch caused adapters to learn calibration-specific patterns that hurt eval PPL.

### 5.2 Solution

Split `eval.jsonl` (100 texts) into:
- Calibration: 80 texts (`data/eval_calib.jsonl`, avg 145 words)
- Validation: 20 texts (`data/eval_val.jsonl`, avg 173 words)

This ensures calibration and evaluation distributions match.

## 6. PPL-Based Alpha Search

### 6.1 Problem

Alpha search based on output reconstruction error (`||T - alpha * X B^T A^T||_F`) selects alphas that minimize error but do not necessarily improve PPL. The output error landscape differs from the PPL landscape.

### 6.2 Solution

For each candidate alpha, attach the adapter and evaluate full PPL on the evaluation set. Select the alpha with the lowest PPL.

Search grid: `[0.05, 0.08, 0.10, 0.12, 0.15, 0.18, 0.20, 0.22, 0.25, 0.28, 0.30, 0.32, 0.35, 0.38, 0.40]`

Optimal alpha for top40: **0.35**

## 7. Multi-Layer Compensation

### 7.1 Layer Selection

72 candidate layers scored by:
```
score = (error_before - error_after) / adapter_param_count
```

Top 40 layers selected. Distribution:
- `mlp.gate_proj`: ~20 layers (high score due to large out_features)
- `self_attn.o_proj`: ~10 layers (highest score, small param count)
- `mlp.down_proj`: ~10 layers

### 7.2 Cumulative Effect

| Layers | Best alpha | PPL | vs AWQ |
|--------|-----------|-----|--------|
| 1 (layer0) | 1.5 | 21.5011 | -0.16% |
| 5 | 0.15 | 21.4377 | -0.46% |
| 10 | 0.15 | 21.3853 | -0.70% |
| 20 | 0.22 | 21.2456 | -1.35% |
| 40 | 0.35 | 21.0379 | -2.32% |

## 8. Final Benchmark Results

| Model | PPL | Tokens/s | Latency | Peak Memory |
|-------|-----|----------|---------|-------------|
| AWQ | 21.5365 | 20.38 | 1.57s | 0.45GB |
| AWQ+QComp | 21.0379 | 18.89 | 1.69s | 0.48GB |

- **PPL improvement**: 2.31%
- **Throughput retention**: 92.7%

## 9. Reproduction

```bash
bash scripts/run_final_qcomp.sh
```

## 10. Artifacts

- Config: `configs/final_qcomp.yaml`
- Adapter: `artifacts/final/qcomp_top40_r8_lam0p1/`
- Results: `results/qcomp_search.csv`
- Report: `artifacts/final/RESULT.md`
