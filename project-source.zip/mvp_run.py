"""End-to-end QComp MVP run on Qwen2.5-0.5B (CPU, no GPU available).

This is a self-contained script that exercises the new qcomp.py /
awq_integration.py / cli.py code paths without requiring an A10 GPU:
  - builds a QComp adapter for model.layers.0.mlp.down_proj
  - prints layer output error before/after
  - prints AWQ PPL and AWQ+QComp PPL
"""
from __future__ import annotations

import os as _os
_os.environ.setdefault("HF_HUB_OFFLINE","1")
_os.environ.setdefault("TRANSFORMERS_OFFLINE","1")
_os.environ.setdefault("HF_DATASETS_OFFLINE","1")

import json
import math
import os
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "")

import torch
import torch.nn.functional as F

from a10_quant_comp.qcomp import fit_qcomp, save_qcomp_adapter, load_qcomp_adapter
from a10_quant_comp.awq_integration import (
    load_awq_model, collect_awq_linear_layers, dequantize_awq_layer,
    apply_compensation_to_awq,
)

MODEL_ID = "Qwen/Qwen2.5-0.5B"
TARGET_LAYER = "model.layers.0.mlp.down_proj"
RANK = 8
WORK = Path("artifacts/mvp_cpu")
WORK.mkdir(parents=True, exist_ok=True)

# ---------------- data ----------------
import pyarrow.parquet as pq
_wt_base = "/root/.cache/huggingface/hub/datasets--wikitext/snapshots/b08601e04326c79dfdd32d625aee71d232d685c3/wikitext-2-raw-v1"
_t = pq.read_table(f"{_wt_base}/test-00000-of-00001.parquet").to_pandas()["text"].tolist()
cal_texts = [t for t in _t if len(t) > 50][:32]
eval_texts = [t for t in _t if len(t) > 200][:50]


def compute_ppl(model, tok, texts, max_len=512):
    total_nll, total_tokens = 0.0, 0
    with torch.no_grad():
        for t in texts:
            enc = tok(t, return_tensors="pt", truncation=True, max_length=max_len)
            ids = enc["input_ids"]
            if ids.size(1) < 2:
                continue
            logits = model(ids).logits
            shift_logits = logits[..., :-1, :].contiguous().float()
            shift_labels = ids[..., 1:].contiguous()
            loss = F.cross_entropy(
                shift_logits.reshape(-1, shift_logits.size(-1)),
                shift_labels.reshape(-1),
                reduction="sum",
            )
            total_nll += float(loss.item())
            total_tokens += int(shift_labels.numel())
    return math.exp(total_nll / max(total_tokens, 1)), total_nll, total_tokens


# ---------------- load models ----------------
from transformers import AutoTokenizer, AutoModelForCausalLM

print(f"[1/5] Loading FP16 model {MODEL_ID} ...")
tok = AutoTokenizer.from_pretrained(MODEL_ID, trust_remote_code=True)
fp_model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID, dtype=torch.float32, trust_remote_code=True,
)
fp_model.eval()

# Simulate AWQ quantization for the target layer by fake-int4 round-trip.
# (No CUDA, so we can't run real AutoAWQ; we emulate the quant error.)
import copy

awq_model = copy.deepcopy(fp_model)


def fake_int4_quant(W, group_size=128):
    """Emulate int4 per-group quantization error (zero-point + scale)."""
    Wf = W.float()
    out_f, in_f = Wf.shape
    Q = torch.zeros_like(Wf)
    for j in range(0, in_f, group_size):
        g = Wf[:, j:j + group_size]
        mn, mx = g.min(), g.max()
        scale = (mx - mn) / 15.0 if (mx - mn) > 0 else torch.tensor(1.0)
        zero = torch.round(-mn / scale).clamp(0, 15)
        q = torch.round(g / scale + zero).clamp(0, 15)
        dq = (q - zero) * scale
        Q[:, j:j + group_size] = dq
    return Q.to(W.dtype)


print(f"[2/5] Emulating AWQ int4 quantization on {TARGET_LAYER} ...")
fp_lin = dict(fp_model.named_modules())[TARGET_LAYER]
W_fp = fp_lin.weight.detach().clone()
Q_awq = fake_int4_quant(W_fp, group_size=128)
awq_lin = dict(awq_model.named_modules())[TARGET_LAYER]
with torch.no_grad():
    awq_lin.weight.copy_(Q_awq)

# ---------------- collect activations ----------------
print(f"[3/5] Collecting input activations for {TARGET_LAYER} ...")
captured = []
def hook(mod, inp, out):
    captured.append(inp[0].detach().float().reshape(-1, inp[0].size(-1)).cpu())
h = fp_lin.register_forward_hook(hook)
with torch.no_grad():
    for t in cal_texts:
        enc = tok(t, return_tensors="pt", truncation=True, max_length=256)
        _ = fp_model(**enc)
h.remove()
X = torch.cat(captured, dim=0)
print(f"       X shape = {X.shape}")

# ---------------- fit qcomp ----------------
error = (W_fp.float() - Q_awq.float()).cpu()
adapter = fit_qcomp(X, error, rank=RANK, alpha=1.0)

y_err_before = X @ error.t()
y_err_after = y_err_before - adapter(X)
before_norm = float(torch.linalg.norm(y_err_before, "fro").item())
after_norm = float(torch.linalg.norm(y_err_after, "fro").item())
ref_norm = float(torch.linalg.norm(X @ W_fp.float().t(), "fro").item())
rel_before = before_norm / max(ref_norm, 1e-12)
rel_after = after_norm / max(ref_norm, 1e-12)

adapter_dir = WORK / f"r{RANK}"
save_qcomp_adapter(adapter, adapter_dir, module_name=TARGET_LAYER,
                   extra={"rank": RANK,
                          "relative_output_error_before": rel_before,
                          "relative_output_error_after": rel_after})
print(f"[4/5] Saved adapter -> {adapter_dir}")

# ---------------- PPL ----------------
print(f"[5/5] Computing PPL ...")
ppl_awq, nll_awq, tok_awq = compute_ppl(awq_model, tok, eval_texts)
print(f"       AWQ PPL = {ppl_awq:.4f}")

# apply QComp compensation to awq_model via monkey-patched forward
# Build a fake "awq_model" wrapper that apply_compensation_to_awq expects
class _ModelHolder:
    def __init__(self, m):
        self.model = m

holder = _ModelHolder(awq_model)
adapters = {TARGET_LAYER: adapter}
# apply_compensation_to_awq expects modules with .qweight; our fake uses .weight.
# Since we deep-copied, we manually patch forward to add the QComp correction.
orig_forward = awq_lin.forward
def patched_forward(x, *a, **k):
    out = orig_forward(x, *a, **k)
    z = F.linear(x, adapter.B)
    comp = F.linear(z, adapter.A) * adapter.alpha
    return out + comp.to(out.dtype)
awq_lin.forward = patched_forward

ppl_qcomp, nll_qcomp, tok_qcomp = compute_ppl(awq_model, tok, eval_texts)
print(f"       AWQ+QComp PPL = {ppl_qcomp:.4f}")

# ---------------- summary ----------------
print()
print("=" * 60)
print("QComp MVP Summary (Qwen2.5-0.5B, simulated int4 AWQ)")
print("=" * 60)
print(f"Target layer : {TARGET_LAYER}")
print(f"Rank         : {RANK}")
print(f"Layer output error before : {before_norm:.4f} (rel {rel_before:.4f})")
print(f"Layer output error after  : {after_norm:.4f} (rel {rel_after:.4f})")
print(f"AWQ PPL        : {ppl_awq:.4f}")
print(f"AWQ+QComp PPL  : {ppl_qcomp:.4f}")
delta = ppl_qcomp - ppl_awq
rel = delta / ppl_awq if ppl_awq > 0 else float("nan")
print(f"Delta          : {delta:+.4f} ({rel*100:+.2f}%)")
print("=" * 60)

# save summary json
summary = {
    "model": MODEL_ID, "layer": TARGET_LAYER, "rank": RANK,
    "output_error_before": before_norm, "output_error_after": after_norm,
    "relative_output_error_before": rel_before,
    "relative_output_error_after": rel_after,
    "ppl_awq": ppl_awq, "ppl_awq_qcomp": ppl_qcomp,
    "ppl_delta": delta, "ppl_delta_pct": rel * 100,
}
(WORK / "summary.json").write_text(json.dumps(summary, indent=2))
print(f"\nSummary written -> {WORK / 'summary.json'}")
