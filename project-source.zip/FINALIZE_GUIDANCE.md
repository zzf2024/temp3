# QComp Finalization Guidance

## Purpose

Freeze the achieved QComp result and make it reproducible.

Current accepted result:

-   Model: Qwen/Qwen2.5-0.5B
-   Quantization: AWQ W4A16 group_size=128
-   Adapter: top40_r8_lam0p1
-   AWQ PPL: 21.5365
-   QComp PPL: 21.0384
-   PPL improvement: 2.31%
-   Throughput retention: 87.7%

The goal now is not further optimization. The goal is to freeze,
reproduce, and package the result.

------------------------------------------------------------------------

## 1. Freeze Final Configuration

Create:

    configs/final_qcomp.yaml

Record:

``` yaml
qcomp:
  method: qcomp
  selected_layers: top40
  rank: 8
  ridge_lambda: 0.1
  alpha: 0.35

data:
  calibration_path: data/eval_calib.jsonl
  validation_path: data/eval_val.jsonl
  evaluation_path: data/eval.jsonl
```

Do not change this configuration after freezing.

------------------------------------------------------------------------

## 2. Freeze Best Adapter

Copy:

    artifacts/c5fc6a81f2f7/qcomp/top40_r8_lam0p1/

to:

    artifacts/final/qcomp_top40_r8_lam0p1/

Keep:

-   adapter files
-   adapter_config.json
-   manifest.json
-   selected layer information

Add:

    artifacts/final/RESULT.md

with final metrics and git commit hash.

------------------------------------------------------------------------

## 3. Create One-Command Reproduction

Add:

    scripts/run_final_qcomp.sh

The script should:

1.  Load AWQ baseline.
2.  Load final QComp adapter.
3.  Evaluate PPL.
4.  Benchmark throughput.
5.  Generate final report.

No manual parameter input should be required.

------------------------------------------------------------------------

## 4. Create Final Technical Report

Add:

    docs/QComp_Final_Report.md

Include:

-   Problem statement
-   AWQ degradation analysis
-   QComp method
-   Ridge regression formulation
-   Low-rank A/B compensation
-   Calibration distribution matching
-   PPL-based alpha search
-   Multi-layer compensation
-   Final benchmark results

Core formula:

    DeltaY ≈ X B^T A^T

    output =
    AWQ_output + alpha * QComp(x)

------------------------------------------------------------------------

## 5. Final Benchmark Table

Include:

  Model       PPL       Tokens/s
  ----------- --------- ----------
  AWQ         21.5365   20.38
  AWQ+QComp   21.0384   17.88

Final:

-   PPL improvement: 2.31%
-   Throughput retention: 87.7%

------------------------------------------------------------------------

## 6. Cleanup

Remove:

-   temporary experiments
-   failed adapters
-   debug logs

Keep:

    a10_quant_comp/
    configs/
    scripts/
    docs/
    artifacts/final/

------------------------------------------------------------------------

## 7. Version Information

Create:

    VERSION.txt

Record:

    QComp Final Release

    Model:
    Qwen2.5-0.5B

    Method:
    AWQ + QComp

    Adapter:
    top40_r8_lam0p1

    PPL improvement:
    2.31%

    Throughput retention:
    87.7%

------------------------------------------------------------------------

## 8. Final Checklist

Before completion:

-   [ ] final config exists
-   [ ] final adapter frozen
-   [ ] reproduction script works
-   [ ] PPL \<= 21.1058
-   [ ] throughput retention \>= 85%
-   [ ] final report generated
-   [ ] git commit created

------------------------------------------------------------------------

## Final Goal

Another engineer should be able to run:

    bash scripts/run_final_qcomp.sh

and reproduce the accepted result.
