#!/usr/bin/env bash
# Restore NVIDIA A10 device nodes after a freeze/eviction.
# /dev is a tmpfs that sometimes loses the nvidia char devices.
set -e
python3 - << 'PY'
import os, stat
devs = {
    "/dev/nvidia0": (195, 0),
    "/dev/nvidiactl": (195, 255),
    "/dev/nvidia-uvm": (239, 0),
    "/dev/nvidia-uvm-tools": (239, 1),
}
for path, (major, minor) in devs.items():
    if not os.path.exists(path):
        os.mknod(path, stat.S_IFCHR | 0o666, os.makedev(major, minor))
        print(f"created {path}")
    else:
        print(f"{path} exists")
PY
python3 -c "import torch; assert torch.cuda.is_available(), 'CUDA still not available'; print('GPU OK:', torch.cuda.get_device_name(0))"
