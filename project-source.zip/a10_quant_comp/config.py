"""Configuration loading and resolution."""
from __future__ import annotations

import copy
import hashlib
import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

import yaml

DEFAULT_CONFIG: dict[str, Any] = {
    "model": {
        "model_id": None,
        "revision": None,
        "tokenizer_revision": None,
        "max_model_len": 4096,
    },
    "hardware": {
        "device": "cuda:0",
        "required_gpu_name_contains": "A10",
        "dtype": "float16",
    },
    "awq": {
        "bits": 4,
        "group_size": 128,
        "prefer_marlin": True,
    },
    "compensation": {
        "methods": ["svd", "activation_weighted"],
        "ranks": [8, 16],
        "layer_fractions": [0.10, 0.20],
        "regularization": 1.0e-5,
    },
    "data": {
        "calibration_path": None,
        "ppl_eval_path": None,
        "text_field": "text",
    },
    "ppl": {
        "sequence_length": 2048,
        "stride": 512,
    },
    "benchmark": {
        "warmup_requests": 20,
        "measured_requests": 100,
        "repeats": 3,
        "concurrencies": [1, 4, 8],
        "input_token_lengths": [128, 512, 2048],
        "output_token_length": 128,
        "temperature": 0.0,
        "top_p": 1.0,
    },
    "acceptance": {
        "min_throughput_retention": 0.85,
        "min_ppl_degradation_reduction": 0.02,
    },
}


def _deep_merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def load_config(path: str | os.PathLike) -> dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Config not found: {p}")
    with open(p, "r", encoding="utf-8") as f:
        user = yaml.safe_load(f) or {}
    return _deep_merge(DEFAULT_CONFIG, user)


def resolve_config(cfg: dict[str, Any]) -> dict[str, Any]:
    """Return a deep copy with no mutation."""
    return copy.deepcopy(cfg)


def config_hash(cfg: dict[str, Any]) -> str:
    raw = json.dumps(cfg, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def workload_hash(cfg: dict[str, Any]) -> str:
    bm = cfg.get("benchmark", {})
    return config_hash(bm)


def data_hash(path: str | os.PathLike) -> str:
    p = Path(path)
    h = hashlib.sha256()
    if p.is_file():
        h.update(p.read_bytes())
    else:
        h.update(str(p).encode("utf-8"))
    return h.hexdigest()
