"""Reference AWQ W4A16 group quantization (fake-quant) implementation.

Implements weight-only group quantization with per-group scales and optional
activation-based scaling (AWQ). Provides dequantize() to reconstruct Q and a
plain fallback when no calibration activations are available.

This is a CPU/GPU-agnostic reference implementation suitable for correctness
tests and small smoke tests. It is *not* a fused INT4 kernel: dequantization
produces an FP16 tensor Q so that downstream PPL/compensation math is exact.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import torch


@dataclass
class AWQConfig:
    bits: int = 4
    group_size: int = 128
    prefer_marlin: bool = True

    def __post_init__(self):
        if self.bits <= 0:
            raise ValueError("bits must be positive")
        if self.group_size <= 0:
            raise ValueError("group_size must be positive")


@dataclass
class QuantizedWeight:
    """Container for a quantized linear weight tensor.

    qweight: int8-packed quantized codes (values in [-2^(b-1), 2^(b-1)-1])
    scales: per-group scale, shape (out_features, n_groups)
    qmin, qmax: symmetric range
    shape: original (out_features, in_features)
    group_size: int
    bits: int
    """
    qweight: torch.Tensor
    scales: torch.Tensor
    qmin: int
    qmax: int
    shape: tuple[int, int]
    group_size: int
    bits: int
    marlin_active: bool = False

    @property
    def out_features(self) -> int:
        return self.shape[0]

    @property
    def in_features(self) -> int:
        return self.shape[1]

    @property
    def n_groups(self) -> int:
        return self.scales.shape[1]


def _clamp_codes(codes: torch.Tensor, qmin: int, qmax: int) -> torch.Tensor:
    return codes.round().clamp(qmin, qmax).to(torch.int8)


def quantize_weight_awq(
    weight: torch.Tensor,
    cfg: AWQConfig,
    activation_scale: Optional[torch.Tensor] = None,
    zero_point_shift: bool = False,
) -> QuantizedWeight:
    """Quantize a 2D weight tensor [out, in] with group quantization.

    If activation_scale is provided (shape [in] or [1,in]), applies AWQ
    activation-preserving scaling: weight_eff = weight * s, quantize, then
    dequant scale back by /s.

    Symmetric per-group quantization is used.
    """
    if weight.dim() != 2:
        raise ValueError(f"weight must be 2D, got {weight.dim()}D")
    out_features, in_features = weight.shape
    gs = cfg.group_size
    bits = cfg.bits
    qmin = -(1 << (bits - 1))
    qmax = (1 << (bits - 1)) - 1

    w = weight.detach().clone().float()
    s_act = None
    if activation_scale is not None:
        s_act = activation_scale.detach().float().reshape(-1)
        if s_act.numel() == 1:
            s_act = s_act.expand(in_features)
        if s_act.numel() != in_features:
            raise ValueError(
                f"activation_scale length {s_act.numel()} != in_features {in_features}"
            )
        # AWQ scaling: scale weight columns so that salient channels are preserved.
        s_act = s_act.clamp(min=1e-8)
        w = w * s_act.unsqueeze(0)

    n_groups = (in_features + gs - 1) // gs
    # pad to multiple of group_size
    pad = n_groups * gs - in_features
    if pad > 0:
        w = torch.nn.functional.pad(w, (0, pad), value=0.0)
    w = w.reshape(out_features, n_groups, gs)

    wmax = w.abs().amax(dim=-1, keepdim=True).clamp(min=1e-8)
    scale = wmax / qmax  # [out, n_groups, 1]
    codes = w / scale
    codes = _clamp_codes(codes, qmin, qmax)
    dq = codes.float() * scale  # [out, n_groups, gs]
    dq = dq.reshape(out_features, n_groups * gs)[:, :in_features]

    if s_act is not None:
        dq = dq / s_act.unsqueeze(0)

    scale_out = scale.squeeze(-1)  # [out, n_groups]
    return QuantizedWeight(
        qweight=codes.reshape(out_features, n_groups * gs)[:, :in_features].to(torch.int8),
        scales=scale_out,
        qmin=qmin,
        qmax=qmax,
        shape=(out_features, in_features),
        group_size=gs,
        bits=bits,
        marlin_active=False,
    )


def dequantize(qw: QuantizedWeight) -> torch.Tensor:
    """Reconstruct approximate FP weight Q."""
    out_features, in_features = qw.shape
    gs = qw.group_size
    n_groups = qw.n_groups
    codes = qw.qweight.float().reshape(out_features, n_groups, -1)
    # codes length per group may be padded
    dq = codes * qw.scales.unsqueeze(-1)
    dq = dq.reshape(out_features, -1)[:, :in_features]
    return dq.to(torch.float32)


def quantization_error(weight: torch.Tensor, qw: QuantizedWeight) -> torch.Tensor:
    Q = dequantize(qw)
    return (weight.float() - Q).to(weight.dtype if weight.is_floating_point() else torch.float32)
