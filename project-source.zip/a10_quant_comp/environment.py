"""Environment introspection for A10 validation."""
from __future__ import annotations

import json
import os
import platform
import subprocess
from pathlib import Path
from typing import Any


def _try(cmd: list[str]) -> str:
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return (out.stdout or "") + (out.stderr or "")
    except Exception as e:  # pragma: no cover
        return f"<error: {e}>"


def collect_environment() -> dict[str, Any]:
    env: dict[str, Any] = {
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "cuda_available": False,
        "gpu_name": None,
        "gpu_count": 0,
        "gpu_total_memory_mb": 0,
        "nvidia_driver": None,
        "cuda_runtime": None,
    }
    try:
        import torch  # type: ignore
        env["torch_version"] = torch.__version__
        env["cuda_available"] = bool(torch.cuda.is_available())
        if env["cuda_available"]:
            env["gpu_count"] = torch.cuda.device_count()
            props = torch.cuda.get_device_properties(0)
            env["gpu_name"] = props.name
            env["gpu_total_memory_mb"] = int(props.total_memory / 1024 / 1024)
    except Exception as e:  # pragma: no cover
        env["torch_version"] = None
        env["torch_error"] = str(e)

    try:
        import transformers  # type: ignore
        env["transformers_version"] = transformers.__version__
    except Exception:  # pragma: no cover
        env["transformers_version"] = None

    for pkg in ("vllm", "autoawq", "awq", "peft", "accelerate", "datasets", "safetensors"):
        try:
            mod = __import__(pkg)
            env[f"{pkg}_version"] = getattr(mod, "__version__", "unknown")
        except Exception:  # pragma: no cover
            env[f"{pkg}_version"] = None

    nvidia = _try(["nvidia-smi", "--query-gpu=driver_version,name", "--format=csv,noheader"])
    env["nvidia_smi"] = nvidia.strip() if nvidia else None
    env["git_commit"] = _git_commit()
    return env


def _git_commit() -> str | None:
    out = _try(["git", "rev-parse", "HEAD"])
    return out.strip() or None


def check_a10(env: dict[str, Any], required_contains: str = "A10") -> tuple[bool, str]:
    name = env.get("gpu_name") or ""
    if required_contains.lower() in name.lower():
        return True, f"GPU '{name}' matches '{required_contains}'"
    return False, f"GPU '{name}' does not contain '{required_contains}'"


def save_environment(env: dict[str, Any], path: str | Path) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(env, f, indent=2, ensure_ascii=False, default=str)
