"""Model loading helpers (lazy imports for testability on CPU)."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Optional

import torch


def load_model(
    model_id: str,
    revision: Optional[str] = None,
    tokenizer_revision: Optional[str] = None,
    dtype: str = "float16",
    device: str = "cuda:0",
    max_model_len: int = 4096,
):
    """Load a HF causal LM + tokenizer. Returns (model, tokenizer)."""
    from transformers import AutoModelForCausalLM, AutoTokenizer

    dt = getattr(torch, dtype, torch.float16)
    tokenizer = AutoTokenizer.from_pretrained(model_id, revision=tokenizer_revision, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_id, revision=revision, torch_dtype=dt, trust_remote_code=True
    )
    model.to(device)
    model.eval()
    return model, tokenizer


def collect_linear_layers(model) -> dict[str, torch.nn.Linear]:
    """Return {module_name: Linear} for all nn.Linear in the model."""
    out: dict[str, torch.nn.Linear] = {}
    for name, mod in model.named_modules():
        if isinstance(mod, torch.nn.Linear):
            out[name] = mod
    return out


def apply_adapter_to_weight(linear: torch.nn.Linear, adapter) -> None:
    """Apply low-rank delta to a linear layer's weight in-place: W_comp = Q + AB."""
    with torch.no_grad():
        delta = adapter.delta().to(linear.weight.dtype)
        linear.weight.add_(delta)


def model_manifest(model, awq_config: dict, checkpoint_path: Optional[str] = None) -> dict:
    linears = collect_linear_layers(model)
    return {
        "num_linear_layers": len(linears),
        "linear_layer_names": list(linears.keys()),
        "awq_config": awq_config,
        "checkpoint_path": checkpoint_path,
    }


def file_hash(path: str | Path) -> str:
    p = Path(path)
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def save_manifest(manifest: dict, path: str | Path) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False, default=str)
