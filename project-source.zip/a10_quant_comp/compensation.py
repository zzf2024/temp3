"""Low-rank compensation for AWQ quantization error.

Two methods:
  - svd: E = W - Q; E ~= A @ B via truncated SVD (plain, correctness baseline)
  - activation_weighted: min ||X(W-Q-AB)^T||_F^2 using diagonal second-moment weighting
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional

import torch


EPS = 1e-12


def _check_finite(t: torch.Tensor, name: str) -> None:
    if not torch.isfinite(t).all():
        raise ValueError(f"{name} contains NaN/Inf")


@dataclass
class LowRankAdapter:
    """A [out, rank], B [rank, in]; effective delta = A @ B."""
    A: torch.Tensor
    B: torch.Tensor
    method: str
    rank: int
    module_name: str

    @property
    def out_features(self) -> int:
        return self.A.shape[0]

    @property
    def in_features(self) -> int:
        return self.B.shape[1]

    @property
    def param_count(self) -> int:
        return self.A.numel() + self.B.numel()

    def delta(self) -> torch.Tensor:
        return self.A @ self.B

    def weighted_delta(self, X: torch.Tensor) -> torch.Tensor:
        """X [N, in] -> X @ (AB)^T  = X @ B^T @ A^T  [N, out]."""
        return (X @ self.B.t()) @ self.A.t()


def svd_compensate(E: torch.Tensor, rank: int) -> tuple[LowRankAdapter, float]:
    """Plain truncated SVD of E.

    Returns (adapter, relative_residual) where relative_residual =
    ||E - AB||_F / max(||E||_F, eps). Guarantees residual does not increase.
    """
    if E.dim() != 2:
        raise ValueError("E must be 2D")
    _check_finite(E, "E")
    out_features, in_features = E.shape
    rank = max(1, min(rank, min(out_features, in_features)))
    U, S, Vh = torch.linalg.svd(E.float(), full_matrices=False)
    A = (U[:, :rank] * S[:rank].unsqueeze(0)).contiguous()  # [out, rank]
    B = Vh[:rank, :].contiguous()  # [rank, in]
    recon = A @ B
    num = torch.linalg.norm(E - recon, ord="fro")
    den = torch.linalg.norm(E, ord="fro").clamp(min=EPS)
    rel = float((num / den).item())
    return LowRankAdapter(A, B, "svd", rank, ""), rel


def activation_weighted_compensate(
    E: torch.Tensor,
    X: torch.Tensor,
    rank: int,
    regularization: float = 1.0e-5,
) -> tuple[LowRankAdapter, float]:
    """Activation-weighted low-rank approximation minimizing ||X(E-AB)^T||_F^2.

    Uses diagonal second-moment weighting h = mean(X^2, dim=0), R=diag(sqrt(h+lambda)),
    E_weighted = E @ R, truncated SVD, then B = B_weighted @ R^{-1}.

    Avoids explicit matrix inverse by elementwise division.
    """
    if E.dim() != 2:
        raise ValueError("E must be 2D")
    if X.dim() != 2:
        raise ValueError("X must be 2D")
    _check_finite(E, "E")
    _check_finite(X, "X")
    out_features, in_features = E.shape
    if X.size(-1) != in_features:
        raise ValueError(
            f"X in_features {X.size(-1)} != E in_features {in_features}"
        )
    rank = max(1, min(rank, min(out_features, in_features)))
    lam = float(regularization)
    h = (X.float() ** 2).mean(dim=0)  # [in]
    h = h.clamp(min=0.0) + lam
    R_diag = torch.sqrt(h)  # [in]
    E_w = E.float() * R_diag.unsqueeze(0)  # [out, in]
    U, S, Vh = torch.linalg.svd(E_w, full_matrices=False)
    A = (U[:, :rank] * S[:rank].unsqueeze(0)).contiguous()  # [out, rank]
    Bw = Vh[:rank, :].contiguous()  # [rank, in]
    # B = Bw * R^{-1}, elementwise (no explicit inverse matrix)
    R_inv = 1.0 / R_diag.clamp(min=EPS)
    B = Bw * R_inv.unsqueeze(0)
    # weighted residual: || X (E - AB)^T ||_F
    delta = E - A @ B
    weighted = (X.float() @ delta.t())  # [N, out]
    num = torch.linalg.norm(weighted, ord="fro")
    ref = torch.linalg.norm(X.float() @ E.t(), ord="fro").clamp(min=EPS)
    rel = float((num / ref).item())
    return LowRankAdapter(A, B, "activation_weighted", rank, ""), rel


def lora_mapping(adapter: LowRankAdapter) -> tuple[torch.Tensor, torch.Tensor]:
    """Map delta_W = A @ B onto PEFT LoRA: lora_A = B, lora_B = A (no scaling)."""
    return adapter.B, adapter.A


def lora_effective(lora_A: torch.Tensor, lora_B: torch.Tensor) -> torch.Tensor:
    """Effective LoRA update = lora_B @ lora_A = A @ B = delta_W."""
    return lora_B @ lora_A


def save_adapter(adapter: LowRankAdapter, path: str | Path, extra: Optional[dict] = None) -> None:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    cfg = {
        "method": adapter.method,
        "rank": adapter.rank,
        "module_name": adapter.module_name,
        "out_features": adapter.out_features,
        "in_features": adapter.in_features,
        "param_count": adapter.param_count,
    }
    if extra:
        cfg.update(extra)
    with open(p / "adapter_config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    # safetensors if available, else torch
    try:
        from safetensors.torch import save_file
        save_file(
            {"A": adapter.A.contiguous().to(torch.float32), "B": adapter.B.contiguous().to(torch.float32)},
            str(p / "adapter_model.safetensors"),
        )
    except Exception:  # pragma: no cover
        torch.save(
            {"A": adapter.A, "B": adapter.B},
            p / "adapter_model.pt",
        )


def load_adapter(path: str | Path) -> LowRankAdapter:
    p = Path(path)
    with open(p / "adapter_config.json", "r", encoding="utf-8") as f:
        cfg = json.load(f)
    A = B = None
    st = p / "adapter_model.safetensors"
    if st.exists():
        from safetensors.torch import load_file
        d = load_file(str(st))
        A, B = d["A"], d["B"]
    else:
        d = torch.load(p / "adapter_model.pt")
        A, B = d["A"], d["B"]
    return LowRankAdapter(A, B, cfg["method"], cfg["rank"], cfg["module_name"])
