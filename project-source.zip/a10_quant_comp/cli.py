"""Command-line interface for the two-stage AWQ compensation experiment."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import statistics
import sys
import time
from pathlib import Path
from typing import Any, Optional

import torch
import yaml

from . import __version__
from .acceptance import evaluate_acceptance, save_acceptance, compute_throughput_retention
from .baseline_lock import BaselineLock, save_lock, load_lock, verify_lock
from .compensation import (
    LowRankAdapter,
    svd_compensate,
    activation_weighted_compensate,
    lora_mapping,
    lora_effective,
    save_adapter,
    load_adapter,
)
from .config import load_config, resolve_config, config_hash, workload_hash, data_hash
from .environment import collect_environment, check_a10, save_environment
from .logging_utils import setup_logger
from .ppl import PPLResult, ppl_from_nll, ppl_delta, ppl_degradation_reduction, save_ppl, load_ppl
from .sensitivity import relative_output_error, LayerSensitivity, select_top_fraction, write_sensitivity_csv, compute_output_error_improvement
from .qcomp.collect import output_error_score
from .qcomp.select import select_layers
from .qcomp.build import build_layer_adapter


QCOMP_TARGET_LAYER = "model.layers.0.mlp.down_proj"
QCOMP_CANDIDATE_TYPES = ["mlp.down_proj", "self_attn.o_proj", "mlp.gate_proj"]
QCOMP_ALPHA_GRID = [0.25, 0.5, 0.75, 1.0]


def _run_id(cfg: dict) -> str:
    return config_hash(cfg)[:12]


def _artifacts_dir(cfg: dict) -> Path:
    return Path("artifacts") / _run_id(cfg)


def _write_resolved_config(cfg: dict, run_dir: Path) -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "logs").mkdir(parents=True, exist_ok=True)
    with open(run_dir / "resolved_config.yaml", "w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, sort_keys=True)


def _guard_overwrite(path: Path, overwrite: bool) -> None:
    if path.exists() and not overwrite:
        raise SystemExit(f"Refusing to overwrite existing: {path} (pass --overwrite)")


def _load_cfg(args) -> dict:
    return load_config(args.config)


def _load_texts(path: str, text_field: str) -> list[str]:
    p = Path(path)
    texts = []
    if p.suffix in (".json", ".jsonl"):
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                obj = json.loads(line)
                texts.append(obj.get(text_field, ""))
    else:
        texts = [p.read_text(encoding="utf-8")]
    return [t for t in texts if t.strip()]


def _compute_ppl(model, tokenizer, cfg, log, max_samples=None, eval_path=None):
    """Compute total NLL over a dataset using sliding window (total NLL / total tokens).

    If *eval_path* is given, use that instead of cfg['data']['ppl_eval_path'].
    """
    seq_len = cfg["ppl"]["sequence_length"]
    stride = cfg["ppl"]["stride"]
    if eval_path is None:
        eval_path = cfg["data"]["ppl_eval_path"]
    if eval_path is None:
        raise SystemExit("data.ppl_eval_path not set")
    text_field = cfg["data"]["text_field"]
    texts = _load_texts(eval_path, text_field)
    if max_samples:
        texts = texts[:max_samples]
    device = cfg["hardware"]["device"]
    total_nll = 0.0
    total_tokens = 0
    n_samples = 0
    import torch.nn.functional as F
    with torch.no_grad():
        for idx, text in enumerate(texts):
            enc = tokenizer(text, return_tensors="pt")
            input_ids = enc["input_ids"][0]
            T = input_ids.size(0)
            if T <= 1:
                continue
            n_samples += 1
            for begin in range(0, T, stride):
                end = min(begin + seq_len, T)
                if end - begin < 2:
                    break
                chunk = input_ids[begin:end].unsqueeze(0).to(device)
                logits = model(chunk).logits
                shift_logits = logits[..., :-1, :].contiguous()
                shift_labels = chunk[..., 1:].contiguous()
                mask = shift_labels != -100
                valid = mask.sum().item()
                if valid == 0:
                    continue
                loss = F.cross_entropy(
                    shift_logits.float().reshape(-1, shift_logits.size(-1)),
                    shift_labels.reshape(-1),
                    reduction="sum",
                    ignore_index=-100,
                )
                total_nll += float(loss.item())
                total_tokens += valid
                if end == T:
                    break
            if (idx + 1) % 200 == 0:
                log.info("  processed %d/%d samples, running PPL=%.2f",
                         idx + 1, len(texts), _safe_exp(total_nll, total_tokens))
    log.info("NLL=%s tokens=%s samples=%s", total_nll, total_tokens, n_samples)
    return total_nll, total_tokens, n_samples


def _safe_exp(nll, tokens):
    if tokens <= 0:
        return float("nan")
    import math
    return math.exp(nll / tokens)


# ---- Stage 1 commands ----

def cmd_check_env(args) -> int:
    cfg = _load_cfg(args)
    if args.dry_run:
        print(f"[dry-run] check-env for config {args.config}")
        return 0
    run_dir = _artifacts_dir(cfg)
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "logs").mkdir(parents=True, exist_ok=True)
    _write_resolved_config(cfg, run_dir)
    log = setup_logger("check_env", run_dir / "logs")
    env = collect_environment()
    required = cfg["hardware"]["required_gpu_name_contains"]
    ok, msg = check_a10(env, required)
    env["a10_check_passed"] = ok
    env["a10_check_message"] = msg
    if not ok:
        env["status"] = "BLOCKED_FOR_A10_VALIDATION"
    save_environment(env, run_dir / "environment.json")
    log.info(msg)
    print(json.dumps({"a10": ok, "message": msg, "gpu": env.get("gpu_name")}, indent=2))
    return 0


def cmd_eval_fp16_ppl(args) -> int:
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("eval_fp16_ppl", run_dir / "logs")
    out_path = run_dir / "baseline" / "fp16_ppl.json"
    _guard_overwrite(out_path, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would compute FP16 PPL -> {out_path}")
        return 0
    from transformers import AutoTokenizer, AutoModelForCausalLM
    mid = cfg["model"]["model_id"]
    log.info("Loading FP16 model %s", mid)
    tok = AutoTokenizer.from_pretrained(mid, revision=cfg["model"]["tokenizer_revision"],
                                        trust_remote_code=True)
    dt = getattr(torch, cfg["hardware"]["dtype"], torch.float16)
    model = AutoModelForCausalLM.from_pretrained(
        mid, revision=cfg["model"]["revision"], dtype=dt, trust_remote_code=True
    ).to(cfg["hardware"]["device"])
    model.eval()
    total_nll, total_tokens, n_samples = _compute_ppl(model, tok, cfg, log)
    ppl = ppl_from_nll(total_nll, total_tokens)
    res = PPLResult(total_nll, total_tokens, n_samples, ppl, mid, cfg["model"]["revision"])
    save_ppl(res, out_path)
    log.info("FP16 PPL = %.4f", ppl)
    del model
    torch.cuda.empty_cache()
    return 0


def cmd_quantize_awq(args) -> int:
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("quantize_awq", run_dir / "logs")
    ckpt_dir = run_dir / "baseline" / "awq_checkpoint"
    manifest_path = run_dir / "baseline" / "awq_model_manifest.json"
    _guard_overwrite(ckpt_dir, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would quantize AWQ -> {ckpt_dir}")
        return 0
    from .awq_integration import quantize_model, load_awq_model, collect_awq_linear_layers
    cal_texts = _load_texts(cfg["data"]["calibration_path"], cfg["data"]["text_field"])
    log.info("Quantizing %s with AutoAWQ (%d cal texts)", cfg["model"]["model_id"], len(cal_texts))
    quantize_model(
        cfg["model"]["model_id"], ckpt_dir, cal_texts,
        bits=cfg["awq"]["bits"], group_size=cfg["awq"]["group_size"],
        revision=cfg["model"]["revision"],
        tokenizer_revision=cfg["model"]["tokenizer_revision"],
    )
    # build manifest
    awq_model = load_awq_model(ckpt_dir, cfg["hardware"]["device"])
    layers = collect_awq_linear_layers(awq_model)
    manifest = {
        "num_quantized_layers": len(layers),
        "quantized_layer_names": list(layers.keys()),
        "awq_config": cfg["awq"],
        "checkpoint_path": str(ckpt_dir),
    }
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False, default=str)
    log.info("Quantized %d layers -> %s", len(layers), ckpt_dir)
    del awq_model
    torch.cuda.empty_cache()
    return 0


def cmd_eval_awq_ppl(args) -> int:
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("eval_awq_ppl", run_dir / "logs")
    out_path = run_dir / "baseline" / "awq_ppl.json"
    _guard_overwrite(out_path, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would compute AWQ PPL -> {out_path}")
        return 0
    from .awq_integration import load_awq_model
    from transformers import AutoTokenizer
    ckpt_dir = run_dir / "baseline" / "awq_checkpoint"
    log.info("Loading AWQ model from %s", ckpt_dir)
    tok = AutoTokenizer.from_pretrained(str(ckpt_dir), trust_remote_code=True)
    model = load_awq_model(ckpt_dir, cfg["hardware"]["device"])
    model.model.eval()
    total_nll, total_tokens, n_samples = _compute_ppl(model.model, tok, cfg, log)
    ppl = ppl_from_nll(total_nll, total_tokens)
    res = PPLResult(total_nll, total_tokens, n_samples, ppl,
                    cfg["model"]["model_id"], cfg["model"]["revision"])
    save_ppl(res, out_path)
    log.info("AWQ PPL = %.4f", ppl)
    del model
    torch.cuda.empty_cache()
    return 0


def cmd_benchmark_awq(args) -> int:
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("benchmark_awq", run_dir / "logs")
    out_path = run_dir / "baseline" / "awq_benchmark.json"
    raw_path = run_dir / "baseline" / "awq_raw_requests.jsonl"
    _guard_overwrite(out_path, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would benchmark AWQ -> {out_path}")
        return 0
    from .awq_integration import load_awq_model
    from transformers import AutoTokenizer
    ckpt_dir = run_dir / "baseline" / "awq_checkpoint"
    log.info("Loading AWQ model for benchmark")
    tok = AutoTokenizer.from_pretrained(str(ckpt_dir), trust_remote_code=True)
    model = load_awq_model(ckpt_dir, cfg["hardware"]["device"])
    device = cfg["hardware"]["device"]
    results = _run_benchmarks(model.model, tok, cfg, log, device)
    _save_benchmark(results, out_path, raw_path)
    del model
    torch.cuda.empty_cache()
    return 0


def _run_benchmarks(model, tokenizer, cfg, log, device, adapters=None):
    """Run all benchmark workloads; returns list of WorkloadResult."""
    from .benchmark import run_workload
    if adapters:
        from .awq_integration import apply_compensation_to_awq
        apply_compensation_to_awq(model, adapters)

    def gen_fn(batch, max_new_tokens):
        pad = tokenizer.pad_token_id or tokenizer.eos_token_id
        max_len = max(int(x.size(-1)) for x in batch)
        input_ids = torch.full((len(batch), max_len), pad, dtype=torch.long)
        attn = torch.zeros((len(batch), max_len), dtype=torch.long)
        for i, x in enumerate(batch):
            n = int(x.size(-1))
            input_ids[i, :n] = x
            attn[i, :n] = 1
        input_ids = input_ids.to(device)
        attn = attn.to(device)
        out = model.generate(
            input_ids=input_ids, attention_mask=attn,
            max_new_tokens=max_new_tokens, do_sample=False,
        )
        return [out[i, input_ids.size(1):] for i in range(len(batch))]

    results = []
    bm = cfg["benchmark"]
    dummy = torch.randint(0, 1000, (2200,))
    for in_len in bm["input_token_lengths"]:
        for conc in bm["concurrencies"]:
            wr = run_workload(
                gen_fn, dummy, in_len, bm["output_token_length"],
                conc, bm["repeats"], device,
            )
            results.append(wr)
            log.info("in=%d conc=%d oom=%s", in_len, conc, wr.oom)
    return results


def _save_benchmark(results, out_path, raw_path):
    from .benchmark import save_benchmark
    save_benchmark(results, out_path)
    with open(raw_path, "w", encoding="utf-8") as f:
        for r in results:
            agg = r.aggregate()
            f.write(json.dumps(agg, default=str) + "\n")


def cmd_freeze_baseline(args) -> int:
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("freeze_baseline", run_dir / "logs")
    lock_path = run_dir / "baseline" / "baseline_lock.json"
    _guard_overwrite(lock_path, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would freeze baseline -> {lock_path}")
        return 0
    required = ["fp16_ppl.json", "awq_ppl.json", "awq_benchmark.json", "awq_model_manifest.json"]
    for r in required:
        p = run_dir / "baseline" / r
        if not p.exists():
            raise SystemExit(f"Missing required baseline artifact: {p}")
    env_path = run_dir / "environment.json"
    env = json.loads(env_path.read_text()) if env_path.exists() else {}
    awq_ckpt = run_dir / "baseline" / "awq_checkpoint"
    ckpt_hash = None
    if awq_ckpt.exists():
        h = hashlib.sha256()
        for f in sorted(awq_ckpt.rglob("*")):
            if f.is_file():
                h.update(f.read_bytes())
        ckpt_hash = h.hexdigest()
    ppl_path = cfg["data"]["ppl_eval_path"]
    ppl_hash = data_hash(ppl_path) if ppl_path else ""
    lock = BaselineLock(
        model_id=cfg["model"]["model_id"],
        revision=cfg["model"]["revision"],
        tokenizer_revision=cfg["model"]["tokenizer_revision"],
        awq_checkpoint_path=str(awq_ckpt),
        awq_checkpoint_hash=ckpt_hash,
        awq_config=cfg["awq"],
        ppl_data_hash=ppl_hash,
        benchmark_workload_hash=workload_hash(cfg),
        serving_config=cfg["benchmark"],
        git_commit=env.get("git_commit"),
    )
    save_lock(lock, lock_path)
    log.info("Baseline frozen -> %s", lock_path)
    return 0


# ---- QComp MVP commands ----

def cmd_build_qcomp(args) -> int:
    """Build QComp A/B adapter for a single target layer.

    Steps:
      1. Load FP16 + AWQ models.
      2. Collect input activations X for QCOMP_TARGET_LAYER.
      3. error = W_fp16 - Q_awq (dequantised).
      4. fit_qcomp(X, error, rank) -> A [out,r], B [r,in].
      5. Save adapter.
      6. Print layer output error before/after compensation.
    """
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("build_qcomp", run_dir / "logs")
    rank = int(args.rank)
    adapter_dir = run_dir / "qcomp" / f"r{rank}"
    _guard_overwrite(adapter_dir, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would build qcomp r{rank} for {QCOMP_TARGET_LAYER} -> {adapter_dir}")
        return 0
    from transformers import AutoTokenizer, AutoModelForCausalLM
    from .awq_integration import load_awq_model, collect_awq_linear_layers, dequantize_awq_layer
    from .qcomp import fit_qcomp, save_qcomp_adapter
    mid = cfg["model"]["model_id"]
    log.info("Building QComp adapter for %s rank=%d", QCOMP_TARGET_LAYER, rank)
    tok = AutoTokenizer.from_pretrained(mid, revision=cfg["model"]["tokenizer_revision"],
                                        trust_remote_code=True)
    fp_model = AutoModelForCausalLM.from_pretrained(
        mid, revision=cfg["model"]["revision"],
        dtype=getattr(torch, cfg["hardware"]["dtype"], torch.float16),
        trust_remote_code=True,
    ).to(cfg["hardware"]["device"])
    fp_model.eval()
    awq_model = load_awq_model(run_dir / "baseline" / "awq_checkpoint", cfg["hardware"]["device"])
    awq_layers = collect_awq_linear_layers(awq_model)
    if QCOMP_TARGET_LAYER not in awq_layers:
        raise SystemExit(f"Target layer {QCOMP_TARGET_LAYER} not found in AWQ model; "
                         f"available: {list(awq_layers.keys())[:5]} ...")
    fp_lin = dict(fp_model.named_modules()).get(QCOMP_TARGET_LAYER)
    if fp_lin is None or not hasattr(fp_lin, "weight"):
        raise SystemExit(f"FP16 layer {QCOMP_TARGET_LAYER} not found or has no weight")
    # collect input activations for the target layer
    cal_texts = _load_texts(cfg["data"]["calibration_path"], cfg["data"]["text_field"])
    X = _collect_input_activations(fp_model, tok, QCOMP_TARGET_LAYER, fp_lin,
                                   cal_texts, cfg, log).cpu()
    W = fp_lin.weight.detach().to(torch.float32).cpu()
    Q = dequantize_awq_layer(awq_layers[QCOMP_TARGET_LAYER]).to(torch.float32).cpu()
    error = W - Q
    adapter = fit_qcomp(X, error, rank=rank, alpha=1.0)
    # output error before/after in activation space
    from .qcomp import QCompAdapter
    y_err_before = X.float() @ error.t()
    correction = adapter(X.float())
    y_err_after = y_err_before - correction
    before_norm = float(torch.linalg.norm(y_err_before, ord="fro").item())
    after_norm = float(torch.linalg.norm(y_err_after, ord="fro").item())
    ref_norm = float(torch.linalg.norm(X.float() @ W.t(), ord="fro").item())
    rel_before = before_norm / max(ref_norm, 1e-12)
    rel_after = after_norm / max(ref_norm, 1e-12)
    save_qcomp_adapter(adapter, adapter_dir, module_name=QCOMP_TARGET_LAYER,
                       extra={"rank": rank,
                              "relative_output_error_before": rel_before,
                              "relative_output_error_after": rel_after,
                              "output_error_before": before_norm,
                              "output_error_after": after_norm})
    log.info("Layer %s output error: before=%.4f after=%.4f (rel %.4f -> %.4f)",
             QCOMP_TARGET_LAYER, before_norm, after_norm, rel_before, rel_after)
    print(f"[build-qcomp] layer={QCOMP_TARGET_LAYER} rank={rank}")
    print(f"[build-qcomp] output error before = {before_norm:.4f} (rel {rel_before:.4f})")
    print(f"[build-qcomp] output error after  = {after_norm:.4f} (rel {rel_after:.4f})")
    print(f"[build-qcomp] adapter saved -> {adapter_dir}")
    del fp_model, awq_model
    torch.cuda.empty_cache()
    return 0


def _load_qcomp_adapters(adapter_path: Path) -> dict:
    """Load QComp A/B adapter(s) from a directory."""
    from .qcomp import load_qcomp_adapter
    adapters = {}
    # single-layer MVP: adapter at top-level of adapter_path
    cfg_file = adapter_path / "adapter_config.json"
    if cfg_file.exists():
        adapter, name = load_qcomp_adapter(adapter_path)
        adapters[name] = adapter
        return adapters
    # fallback: nested per-layer dirs (compatible with multi-layer layout)
    for layer_dir in sorted(adapter_path.iterdir()):
        if not layer_dir.is_dir():
            continue
        if not (layer_dir / "adapter_config.json").exists():
            continue
        adapter, name = load_qcomp_adapter(layer_dir)
        adapters[name] = adapter
    return adapters


def cmd_build_qcomp_single(args) -> int:
    """Build single-layer QComp adapter using output-space fit with ridge regression.

    Collects X_awq, Y_fp, Y_awq for the target layer.  Supports separate
    calibration and validation text files: fits on calibration, searches
    alpha on validation.  If --val-path is omitted, falls back to 50/50
    split of the calibration texts.
    """
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("build_qcomp_single", run_dir / "logs")
    rank = int(args.rank)
    layer_name = args.layer
    max_texts = int(args.max_texts)
    ridge_lambda = float(getattr(args, "ridge_lambda", 1e-2))
    calib_path = getattr(args, "calib_path", None) or cfg["data"]["calibration_path"]
    val_path = getattr(args, "val_path", None)
    # unique adapter dir including lambda tag
    lam_tag = f"_lam{ridge_lambda}".replace(".", "p")
    adapter_dir = run_dir / "qcomp" / f"single_{layer_name.split('.')[-2]}_r{rank}{lam_tag}"
    _guard_overwrite(adapter_dir, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would build qcomp single r{rank} lam={ridge_lambda} for {layer_name} -> {adapter_dir}")
        return 0
    from transformers import AutoTokenizer, AutoModelForCausalLM
    from .awq_integration import load_awq_model
    from .qcomp import fit_qcomp_output, search_alpha_output, save_qcomp_adapter
    mid = cfg["model"]["model_id"]
    log.info("Building single-layer QComp: %s rank=%d max_texts=%d ridge_lambda=%s",
             layer_name, rank, max_texts, ridge_lambda)
    tok = AutoTokenizer.from_pretrained(mid, revision=cfg["model"]["tokenizer_revision"],
                                        trust_remote_code=True)
    fp_model = AutoModelForCausalLM.from_pretrained(
        mid, revision=cfg["model"]["revision"],
        dtype=getattr(torch, cfg["hardware"]["dtype"], torch.float16),
        trust_remote_code=True,
    ).to(cfg["hardware"]["device"])
    fp_model.eval()
    awq_model = load_awq_model(run_dir / "baseline" / "awq_checkpoint", cfg["hardware"]["device"])
    cal_texts = _load_texts(calib_path, cfg["data"]["text_field"])
    # collect calibration IO
    io_cal = _collect_qcomp_io_multi(fp_model, awq_model, tok, [layer_name],
                                     cal_texts, cfg, log, max_texts=max_texts)
    io = io_cal.get(layer_name)
    if io is None:
        raise SystemExit(f"No IO data for {layer_name}")
    X_awq, Y_fp, Y_awq = io
    target = (Y_fp - Y_awq).float()
    if val_path:
        # separate validation set
        val_texts = _load_texts(val_path, cfg["data"]["text_field"])
        io_val = _collect_qcomp_io_multi(fp_model, awq_model, tok, [layer_name],
                                         val_texts, cfg, log, max_texts=max_texts)
        io_v = io_val.get(layer_name)
        if io_v is None:
            raise SystemExit(f"No IO data for {layer_name} (validation)")
        X_val, Y_fp_val, Y_awq_val = io_v
        T_val = (Y_fp_val - Y_awq_val).float()
        X_cal, T_cal = X_awq, target
    else:
        # calibration / validation split (50/50)
        n = X_awq.size(0)
        split = n // 2
        X_cal, X_val = X_awq[:split], X_awq[split:]
        T_cal, T_val = target[:split], target[split:]
    log.info("IO: cal=%d val=%d", X_cal.size(0), X_val.size(0))
    adapter = fit_qcomp_output(X_cal, T_cal, rank=rank, alpha=1.0, regularization=ridge_lambda)
    best_alpha, best_err = search_alpha_output(adapter, X_val, T_val)
    adapter.alpha = best_alpha
    before_val = float(torch.linalg.norm(T_val, "fro").item())
    after_val = best_err
    before_cal = float(torch.linalg.norm(T_cal, "fro").item())
    corr_cal = adapter(X_cal)
    after_cal = float(torch.linalg.norm(T_cal - corr_cal, "fro").item())
    save_qcomp_adapter(adapter, adapter_dir, module_name=layer_name,
                       extra={"rank": rank, "alpha": best_alpha,
                              "ridge_lambda": ridge_lambda,
                              "calib_path": calib_path,
                              "val_path": val_path or "split",
                              "cal_error_before": before_cal, "cal_error_after": after_cal,
                              "val_error_before": before_val, "val_error_after": after_val})
    log.info("%s rank=%d lam=%s: cal %.4f->%.4f val %.4f->%.4f alpha=%.4f",
             layer_name, rank, ridge_lambda, before_cal, after_cal, before_val, after_val, best_alpha)
    print(f"[build-qcomp-single] layer={layer_name} rank={rank} ridge_lambda={ridge_lambda}")
    print(f"[build-qcomp-single] cal  error: {before_cal:.4f} -> {after_cal:.4f}")
    print(f"[build-qcomp-single] val  error: {before_val:.4f} -> {after_val:.4f}")
    print(f"[build-qcomp-single] alpha = {best_alpha:.4f}")
    print(f"[build-qcomp-single] adapter saved -> {adapter_dir}")
    del fp_model, awq_model
    torch.cuda.empty_cache()
    return 0


def cmd_eval_qcomp_ppl(args) -> int:
    """Evaluate AWQ+QComp PPL and compare against AWQ PPL.

    Loads the AWQ model, attaches the QComp A/B adapter for the target
    layer, runs the existing PPL evaluation, then prints a comparison
    of AWQ PPL vs AWQ+QComp PPL.
    """
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("eval_qcomp_ppl", run_dir / "logs")
    adapter_path = Path(args.adapter)
    tag = adapter_path.name
    out_path = run_dir / "results" / f"qcomp_ppl_{tag}.json"
    _guard_overwrite(out_path, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would eval qcomp PPL -> {out_path}")
        return 0
    from .awq_integration import load_awq_model, apply_compensation_to_awq
    from transformers import AutoTokenizer
    log.info("Loading AWQ model + QComp adapter %s", adapter_path)
    ckpt_dir = run_dir / "baseline" / "awq_checkpoint"
    tok = AutoTokenizer.from_pretrained(str(ckpt_dir), trust_remote_code=True)
    model = load_awq_model(ckpt_dir, cfg["hardware"]["device"])
    adapters = _load_qcomp_adapters(adapter_path)
    if not adapters:
        raise SystemExit(f"No QComp adapters found in {adapter_path}")
    n = apply_compensation_to_awq(model, adapters)
    log.info("Applied %d QComp adapters", n)
    model.model.eval()
    # alpha override: allow setting alpha at eval time without rebuilding
    alpha_override = getattr(args, "alpha_override", None)
    if alpha_override is not None:
        for name, adapter in adapters.items():
            adapter.alpha = alpha_override
        log.info("Alpha override: %.4f", alpha_override)
    eval_path = getattr(args, "eval_path", None)
    max_samples = getattr(args, "max_samples", None)
    total_nll, total_tokens, n_samples = _compute_ppl(
        model.model, tok, cfg, log, max_samples=max_samples, eval_path=eval_path)
    ppl = ppl_from_nll(total_nll, total_tokens)
    alpha_tag = f"_a{alpha_override}" if alpha_override is not None else ""
    out_path = run_dir / "results" / f"qcomp_ppl_{tag}{alpha_tag}.json"
    _guard_overwrite(out_path, args.overwrite)
    res = PPLResult(total_nll, total_tokens, n_samples, ppl,
                    cfg["model"]["model_id"], cfg["model"]["revision"])
    save_ppl(res, out_path)
    log.info("AWQ+QComp PPL = %.4f", ppl)
    # compare against AWQ baseline PPL if available
    awq_ppl_path = run_dir / "baseline" / "awq_ppl.json"
    awq_ppl = None
    if awq_ppl_path.exists():
        awq_res = load_ppl(awq_ppl_path)
        awq_ppl = awq_res.ppl
    print(f"[eval-qcomp-ppl] AWQ+QComp PPL = {ppl:.4f}")
    if awq_ppl is not None:
        delta = ppl - awq_ppl
        rel = delta / awq_ppl if awq_ppl > 0 else float("nan")
        print(f"[eval-qcomp-ppl] AWQ       PPL = {awq_ppl:.4f}")
        print(f"[eval-qcomp-ppl] delta        = {delta:+.4f} ({rel*100:+.2f}%)")
    else:
        print("[eval-qcomp-ppl] (run eval-awq-ppl first to see comparison)")
    del model
    torch.cuda.empty_cache()
    return 0


# ---- QComp multi-layer commands (Task 1-5) ----

def _qcomp_candidate_layers(awq_layers: dict) -> list[str]:
    """Filter AWQ layers to candidate types for QComp."""
    out = []
    for name in awq_layers:
        for suffix in QCOMP_CANDIDATE_TYPES:
            if name.endswith(suffix):
                out.append(name)
                break
    return sorted(out)


def _collect_qcomp_io_multi(fp_model, awq_model, tok, layer_names, texts, cfg, log, max_texts=64):
    """Collect X_awq, Y_fp, Y_awq for multiple layers in single forward passes.

    Hooks both the FP16 and AWQ models.  For each candidate layer captures:
      - X_awq: input to the AWQ quantised layer  [N, in]
      - Y_awq: output from the AWQ quantised layer [N, out]
      - Y_fp:  output from the FP16 layer         [N, out]

    Returns {layer_name: (X_awq, Y_fp, Y_awq)}.
    """
    device = cfg["hardware"]["device"]
    fp_modules = dict(fp_model.named_modules())
    awq_modules = dict(awq_model.model.named_modules())
    captured: dict[str, dict[str, list[torch.Tensor]]] = {}
    hooks = []

    def _make_hook(layer_name, tag):
        def hook(mod, inp, out):
            if tag == "x_awq":
                v = inp[0].detach().float().reshape(-1, inp[0].size(-1))
            else:
                if isinstance(out, tuple):
                    out = out[0]
                v = out.detach().float().reshape(-1, out.size(-1))
            captured.setdefault(layer_name, {}).setdefault(tag, []).append(v.cpu())
        return hook

    for name in layer_names:
        awq_lin = awq_modules.get(name)
        fp_lin = fp_modules.get(name)
        if awq_lin is not None and hasattr(awq_lin, "qweight"):
            hooks.append(awq_lin.register_forward_hook(_make_hook(name, "x_awq")))
            hooks.append(awq_lin.register_forward_hook(_make_hook(name, "y_awq")))
        if fp_lin is not None and hasattr(fp_lin, "weight"):
            hooks.append(fp_lin.register_forward_hook(_make_hook(name, "y_fp")))

    n_texts = min(max_texts, len(texts))
    log.info("Collecting IO: %d forward passes for %d layers (FP16 + AWQ)", n_texts, len(layer_names))
    try:
        with torch.no_grad():
            for t in texts[:max_texts]:
                enc = tok(t, return_tensors="pt", truncation=True,
                          max_length=cfg["ppl"]["sequence_length"])
                enc = {k: v.to(device) for k, v in enc.items()}
                _ = fp_model(**enc)
                _ = awq_model.model(**enc)
    finally:
        for h in hooks:
            h.remove()

    results = {}
    for name in layer_names:
        caps = captured.get(name, {})
        awq_lin = awq_modules.get(name)
        fp_lin = fp_modules.get(name)
        in_f = (awq_lin.in_features if awq_lin and hasattr(awq_lin, "in_features")
                else (fp_lin.in_features if fp_lin and hasattr(fp_lin, "in_features") else 4))
        out_f = (awq_lin.out_features if awq_lin and hasattr(awq_lin, "out_features")
                 else (fp_lin.out_features if fp_lin and hasattr(fp_lin, "out_features") else 4))
        x_awq = torch.cat(caps["x_awq"], dim=0) if caps.get("x_awq") else torch.zeros(4, in_f)
        y_fp = torch.cat(caps["y_fp"], dim=0) if caps.get("y_fp") else torch.zeros(4, out_f)
        y_awq = torch.cat(caps["y_awq"], dim=0) if caps.get("y_awq") else torch.zeros(4, out_f)
        n = min(x_awq.size(0), y_fp.size(0), y_awq.size(0))
        results[name] = (x_awq[:n], y_fp[:n], y_awq[:n])
    log.info("IO collected for %d layers", len(results))
    return results


def cmd_score_qcomp_layers(args) -> int:
    """Task 1: Score all candidate layers and output qcomp_layer_scores.csv.

    For each candidate layer:
      - Collect X (input activations), W_fp16, Q_awq
      - Fit rank-8 QComp adapter
      - Compute before/after output error
      - score = (error_before - error_after) / adapter_param_count
    Output CSV sorted by score descending.
    """
    import csv
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("score_qcomp_layers", run_dir / "logs")
    csv_path = run_dir / "qcomp" / "qcomp_layer_scores.csv"
    _guard_overwrite(csv_path, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would score qcomp layers -> {csv_path}")
        return 0
    from transformers import AutoTokenizer, AutoModelForCausalLM
    from .awq_integration import load_awq_model, collect_awq_linear_layers, dequantize_awq_layer
    from .qcomp import fit_qcomp_output, search_alpha_output
    rank = int(args.rank)
    calib_path = getattr(args, "calib_path", None) or cfg["data"]["calibration_path"]
    max_texts = int(getattr(args, "max_texts", 64))
    ridge_lambda = float(getattr(args, "ridge_lambda", 1e-2))
    mid = cfg["model"]["model_id"]
    log.info("Scoring QComp candidate layers rank=%d calib=%s max_texts=%d", rank, calib_path, max_texts)
    tok = AutoTokenizer.from_pretrained(mid, revision=cfg["model"]["tokenizer_revision"],
                                        trust_remote_code=True)
    fp_model = AutoModelForCausalLM.from_pretrained(
        mid, revision=cfg["model"]["revision"],
        dtype=getattr(torch, cfg["hardware"]["dtype"], torch.float16),
        trust_remote_code=True,
    ).to(cfg["hardware"]["device"])
    fp_model.eval()
    awq_model = load_awq_model(run_dir / "baseline" / "awq_checkpoint", cfg["hardware"]["device"])
    awq_layers = collect_awq_linear_layers(awq_model)
    candidates = _qcomp_candidate_layers(awq_layers)
    log.info("Found %d candidate layers", len(candidates))
    cal_texts = _load_texts(calib_path, cfg["data"]["text_field"])
    io_data = _collect_qcomp_io_multi(fp_model, awq_model, tok, candidates, cal_texts, cfg, log, max_texts=max_texts)
    fp_modules = dict(fp_model.named_modules())
    rows = []
    for name in candidates:
        fp_lin = fp_modules.get(name)
        awq_mod = awq_layers.get(name)
        if fp_lin is None or awq_mod is None:
            continue
        io = io_data.get(name)
        if io is None:
            continue
        X_awq, Y_fp, Y_awq = io
        target = (Y_fp - Y_awq).float()
        adapter = fit_qcomp_output(X_awq, target, rank=rank, alpha=1.0, regularization=ridge_lambda)
        best_alpha, best_err = search_alpha_output(adapter, X_awq, target, QCOMP_ALPHA_GRID)
        before = float(torch.linalg.norm(target, "fro").item())
        after = best_err
        param_count = adapter.A.numel() + adapter.B.numel()
        score = (before - after) / max(param_count, 1)
        rows.append({
            "module_name": name,
            "in_features": int(fp_lin.in_features),
            "out_features": int(fp_lin.out_features),
            "error_before": before,
            "error_after": after,
            "error_reduction": before - after,
            "param_count": param_count,
            "score": score,
        })
        log.info("  %s before=%.4f after=%.4f alpha=%.3f score=%.6f", name, before, after, best_alpha, score)
    rows.sort(key=lambda r: r["score"], reverse=True)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["module_name", "in_features", "out_features",
                                          "error_before", "error_after", "error_reduction",
                                          "param_count", "score"])
        w.writeheader()
        for r in rows:
            w.writerow(r)
    log.info("Wrote %d layer scores -> %s", len(rows), csv_path)
    print(f"[score-qcomp-layers] scored {len(rows)} candidates -> {csv_path}")
    for r in rows[:10]:
        print(f"  {r['module_name']:50s} score={r['score']:.6f} "
              f"reduction={r['error_reduction']:.4f}")
    del fp_model, awq_model
    torch.cuda.empty_cache()
    return 0


def cmd_build_qcomp_multi(args) -> int:
    """Task 2+3: Build multi-layer QComp adapters with alpha search.

    Selects top-N layers from qcomp_layer_scores.csv (or runs scoring if
    missing), fits rank-r QComp adapter per layer, searches alpha, and
    saves each adapter under adapter_dir/layer_name/.
    """
    import csv as _csv
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("build_qcomp_multi", run_dir / "logs")
    num_layers = int(args.num_layers)
    rank = int(args.rank)
    ridge_lambda = float(getattr(args, "ridge_lambda", 1e-2))
    calib_path = getattr(args, "calib_path", None) or cfg["data"]["calibration_path"]
    val_path = getattr(args, "val_path", None)
    max_texts = int(getattr(args, "max_texts", 64))
    lam_tag = f"_lam{ridge_lambda}".replace(".", "p")
    tag = f"top{num_layers}_r{rank}{lam_tag}"
    adapter_dir = run_dir / "qcomp" / tag
    _guard_overwrite(adapter_dir, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would build qcomp {tag} -> {adapter_dir}")
        return 0
    from transformers import AutoTokenizer, AutoModelForCausalLM
    from .awq_integration import load_awq_model, collect_awq_linear_layers, dequantize_awq_layer
    from .qcomp import fit_qcomp_output, search_alpha_output, save_qcomp_adapter
    # load or generate scores
    csv_path = run_dir / "qcomp" / "qcomp_layer_scores.csv"
    if not csv_path.exists():
        log.info("Layer scores not found, running scoring first...")
        import subprocess, sys
        subprocess.run([sys.executable, "-m", "a10_quant_comp.cli", "score-qcomp-layers",
                        "--config", args.config, "--rank", str(rank)], check=True)
    with open(csv_path, "r", encoding="utf-8") as f:
        scores = list(_csv.DictReader(f))
    if not scores:
        raise SystemExit(f"No layer scores in {csv_path}")
    selected = scores[:num_layers]
    selected_names = [r["module_name"] for r in selected]
    log.info("Building QComp for top-%d layers (rank=%d)", num_layers, rank)
    for r in selected:
        log.info("  %s score=%.6f", r["module_name"], float(r["score"]))
    # load models
    mid = cfg["model"]["model_id"]
    tok = AutoTokenizer.from_pretrained(mid, revision=cfg["model"]["tokenizer_revision"],
                                        trust_remote_code=True)
    fp_model = AutoModelForCausalLM.from_pretrained(
        mid, revision=cfg["model"]["revision"],
        dtype=getattr(torch, cfg["hardware"]["dtype"], torch.float16),
        trust_remote_code=True,
    ).to(cfg["hardware"]["device"])
    fp_model.eval()
    awq_model = load_awq_model(run_dir / "baseline" / "awq_checkpoint", cfg["hardware"]["device"])
    awq_layers = collect_awq_linear_layers(awq_model)
    cal_texts = _load_texts(calib_path, cfg["data"]["text_field"])
    io_data = _collect_qcomp_io_multi(fp_model, awq_model, tok, selected_names, cal_texts, cfg, log, max_texts=max_texts)
    # collect validation IO for alpha search if val_path provided
    io_val = {}
    if val_path:
        val_texts = _load_texts(val_path, cfg["data"]["text_field"])
        io_val = _collect_qcomp_io_multi(fp_model, awq_model, tok, selected_names, val_texts, cfg, log, max_texts=max_texts)
    fp_modules = dict(fp_model.named_modules())
    adapter_dir.mkdir(parents=True, exist_ok=True)
    manifest = {"rank": rank, "num_layers": num_layers, "tag": tag, "layers": []}
    for name in selected_names:
        fp_lin = fp_modules.get(name)
        awq_mod = awq_layers.get(name)
        if fp_lin is None or awq_mod is None:
            continue
        io = io_data.get(name)
        if io is None:
            continue
        X_awq, Y_fp, Y_awq = io
        target = (Y_fp - Y_awq).float()
        adapter = fit_qcomp_output(X_awq, target, rank=rank, alpha=1.0, regularization=ridge_lambda)
        # alpha search on validation if available, else on calibration
        if name in io_val:
            Xv, Yfp_v, Yawq_v = io_val[name]
            T_val = (Yfp_v - Yawq_v).float()
            best_alpha, best_err = search_alpha_output(adapter, Xv, T_val)
        else:
            best_alpha, best_err = search_alpha_output(adapter, X_awq, target, QCOMP_ALPHA_GRID)
        adapter.alpha = best_alpha
        before = float(torch.linalg.norm(target, "fro").item())
        after = best_err
        layer_dir = adapter_dir / name.replace(".", "__")
        save_qcomp_adapter(adapter, layer_dir, module_name=name,
                           extra={"rank": rank, "alpha": best_alpha,
                                  "error_before": before, "error_after": after,
                                  "score": next((float(r["score"]) for r in selected
                                                 if r["module_name"] == name), 0.0)})
        manifest["layers"].append({"module_name": name, "alpha": best_alpha,
                                   "error_before": before, "error_after": after})
        log.info("  %s alpha=%.2f before=%.4f after=%.4f", name, best_alpha, before, after)
    import json as _json
    with open(adapter_dir / "manifest.json", "w", encoding="utf-8") as f:
        _json.dump(manifest, f, indent=2, ensure_ascii=False)
    print(f"[build-qcomp-multi] built {len(manifest['layers'])} adapters -> {adapter_dir}")
    del fp_model, awq_model
    torch.cuda.empty_cache()
    return 0


def cmd_benchmark_qcomp(args) -> int:
    """Task 5: Benchmark AWQ+QComp throughput/latency/memory vs AWQ baseline.

    Compares AWQ baseline vs AWQ+QComp adapter.  Records tokens/s,
    latency, and peak GPU memory.
    """
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("benchmark_qcomp", run_dir / "logs")
    adapter_path = Path(args.adapter)
    tag = adapter_path.name
    out_path = run_dir / "results" / f"qcomp_benchmark_{tag}.json"
    _guard_overwrite(out_path, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would benchmark qcomp -> {out_path}")
        return 0
    from .awq_integration import load_awq_model, apply_compensation_to_awq
    from transformers import AutoTokenizer
    ckpt_dir = run_dir / "baseline" / "awq_checkpoint"
    tok = AutoTokenizer.from_pretrained(str(ckpt_dir), trust_remote_code=True)
    device = cfg["hardware"]["device"]
    bm_cfg = cfg["benchmark"]
    in_len = bm_cfg["input_token_lengths"][0]
    out_len = bm_cfg["output_token_length"]
    repeats = bm_cfg.get("repeats", 1)
    warmup = bm_cfg.get("warmup_requests", 5)
    measured = bm_cfg.get("measured_requests", 20)
    results = {"tag": tag, "adapter": str(adapter_path), "workloads": []}
    # Load model
    model = load_awq_model(ckpt_dir, device)
    adapters = _load_qcomp_adapters(adapter_path)
    n = apply_compensation_to_awq(model, adapters)
    log.info("Applied %d QComp adapters", n)
    model.model.eval()
    # warmup
    torch.cuda.reset_peak_memory_stats(device)
    for _ in range(min(warmup, 3)):
        ids = torch.randint(0, 1000, (1, in_len), device=device)
        _ = model.model.generate(ids, max_new_tokens=min(out_len, 16), do_sample=False)
    torch.cuda.synchronize()
    # measured
    for rep in range(repeats):
        torch.cuda.reset_peak_memory_stats(device)
        tps_list, lat_list = [], []
        for _ in range(measured):
            ids = torch.randint(0, 1000, (1, in_len), device=device)
            torch.cuda.synchronize()
            t0 = time.time()
            out = model.model.generate(ids, max_new_tokens=out_len, do_sample=False)
            torch.cuda.synchronize()
            t1 = time.time()
            elapsed = t1 - t0
            n_out = out.size(1) - ids.size(1)
            if n_out > 0 and elapsed > 0:
                tps_list.append(n_out / elapsed)
                lat_list.append(elapsed)
        peak_mem = torch.cuda.max_memory_allocated(device) / 1e9
        results["workloads"].append({
            "rep": rep, "input_len": in_len, "output_len": out_len,
            "output_tokens_per_second": statistics.median(tps_list) if tps_list else 0.0,
            "latency_s": statistics.median(lat_list) if lat_list else 0.0,
            "peak_memory_gb": peak_mem,
        })
        log.info("  rep=%d tps=%.2f lat=%.3fs mem=%.2fGB",
                 rep, results["workloads"][-1]["output_tokens_per_second"],
                 results["workloads"][-1]["latency_s"], peak_mem)
    # load AWQ baseline benchmark if available
    awq_bm_path = run_dir / "baseline" / "awq_benchmark.json"
    awq_tps = None
    if awq_bm_path.exists():
        awq_bm = json.loads(awq_bm_path.read_text())
        wls = awq_bm.get("workloads", [])
        vals = [w.get("output_tokens_per_second", 0) for w in wls if not w.get("oom")]
        if vals:
            awq_tps = statistics.median(vals)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False, default=str)
    comp_tps = results["workloads"][0]["output_tokens_per_second"] if results["workloads"] else 0.0
    print(f"[benchmark-qcomp] tag={tag}")
    print(f"  tokens/s  = {comp_tps:.2f}")
    print(f"  latency   = {results['workloads'][0]['latency_s']:.3f}s" if results["workloads"] else "")
    print(f"  peak mem  = {results['workloads'][0]['peak_memory_gb']:.2f}GB" if results["workloads"] else "")
    if awq_tps:
        retention = comp_tps / awq_tps if awq_tps > 0 else 0.0
        print(f"  AWQ tps   = {awq_tps:.2f}")
        print(f"  retention = {retention:.4f}")
    del model
    torch.cuda.empty_cache()
    return 0


# ---- Stage 2 commands ----

def _verify_lock(cfg, run_dir, log):
    lock_path = run_dir / "baseline" / "baseline_lock.json"
    if not lock_path.exists():
        raise SystemExit("Baseline not frozen; run freeze-baseline first")
    lock = load_lock(lock_path)
    current = {
        "model_id": cfg["model"]["model_id"],
        "revision": cfg["model"]["revision"],
        "tokenizer_revision": cfg["model"]["tokenizer_revision"],
        "awq_checkpoint_path": str(run_dir / "baseline" / "awq_checkpoint"),
        "awq_config": cfg["awq"],
        "ppl_data_hash": data_hash(cfg["data"]["ppl_eval_path"]) if cfg["data"]["ppl_eval_path"] else "",
        "benchmark_workload_hash": workload_hash(cfg),
        "serving_config": cfg["benchmark"],
        "git_commit": lock.git_commit,
    }
    violations = verify_lock(lock, current)
    if violations:
        raise SystemExit("Baseline lock violations:\n" + "\n".join(violations))
    return lock


def _collect_all_activations(model, tokenizer, layer_names, texts, cfg, log, max_texts=8):
    """Collect input activations for all target layers in a single pass.

    Registers forward hooks on every target layer, then runs only max_texts
    forward passes through the model (instead of max_texts * len(layers)).
    Returns {module_name: tensor[N, in_features]}.
    """
    device = cfg["hardware"]["device"]
    fp_modules = dict(model.named_modules())
    captured: dict[str, list[torch.Tensor]] = {}
    hooks = []

    def _make_hook(layer_name):
        def hook(mod, inp, out):
            x = inp[0].detach().float().reshape(-1, inp[0].size(-1))
            captured.setdefault(layer_name, []).append(x.cpu())
        return hook

    for name in layer_names:
        lin = fp_modules.get(name)
        if lin is None or not hasattr(lin, "weight"):
            continue
        hooks.append(lin.register_forward_hook(_make_hook(name)))

    n_texts = min(max_texts, len(texts))
    log.info("Collecting activations: %d forward passes for %d layers", n_texts, len(layer_names))
    try:
        with torch.no_grad():
            for t in texts[:max_texts]:
                enc = tokenizer(t, return_tensors="pt", truncation=True,
                                max_length=cfg["ppl"]["sequence_length"])
                enc = {k: v.to(device) for k, v in enc.items()}
                _ = model(**enc)
    finally:
        for h in hooks:
            h.remove()

    activations: dict[str, torch.Tensor] = {}
    for name in layer_names:
        if name in captured and captured[name]:
            activations[name] = torch.cat(captured[name], dim=0)
        else:
            lin = fp_modules.get(name)
            in_f = lin.in_features if lin and hasattr(lin, "in_features") else 4
            activations[name] = torch.randn(4, in_f)
    log.info("Activations collected for %d layers", len(activations))
    return activations


def _compute_sensitivity(fp_model, tok, awq_layers, cfg, run_dir, log, max_cal=8):
    """Compute per-layer sensitivity using calibration activations.

    Returns (entries, activations) so callers (e.g. build-compensation) can
    reuse the cached activations instead of re-collecting them.
    """
    from .awq_integration import dequantize_awq_layer
    cal_texts = _load_texts(cfg["data"]["calibration_path"], cfg["data"]["text_field"])
    activations = _collect_all_activations(fp_model, tok, list(awq_layers.keys()),
                                           cal_texts, cfg, log, max_cal)
    entries: list[LayerSensitivity] = []
    rank_def = max(cfg["compensation"]["ranks"])
    for name, mod in awq_layers.items():
        fp_lin = dict(fp_model.named_modules()).get(name)
        if fp_lin is None or not hasattr(fp_lin, "weight"):
            continue
        W = fp_lin.weight.detach().to(torch.float32).cpu()
        Q = dequantize_awq_layer(mod).to(torch.float32).cpu()
        X = activations.get(name)
        if X is None:
            X = torch.randn(4, fp_lin.in_features)
        rel, resid = relative_output_error(X, W, Q)
        before, after = compute_output_error_improvement(X, W, Q, rank_def, "svd")
        imp_ratio = (before - after) / max(before, 1e-12)
        entries.append(LayerSensitivity(
            module_name=name, in_features=int(W.shape[1]), out_features=int(W.shape[0]),
            relative_output_error=rel, residual_norm=resid, sensitivity_rank=0,
            selected=False, compensation_rank=0, adapter_param_count=0,
            _improvement_ratio=imp_ratio,
        ))
        log.info("  %s rel_err=%.4f imp=%.4f", name, rel, imp_ratio)
    return entries, activations


def _collect_input_activations(model, tokenizer, layer_name, linear, texts, cfg, log, max_texts=8):
    device = cfg["hardware"]["device"]
    captured = {}

    def hook(mod, inp, out):
        x = inp[0].detach().float().reshape(-1, inp[0].size(-1))
        captured["x"] = x.cpu()

    h = linear.register_forward_hook(hook)
    xs = []
    try:
        with torch.no_grad():
            for t in texts[:max_texts]:
                enc = tokenizer(t, return_tensors="pt", truncation=True,
                                max_length=cfg["ppl"]["sequence_length"])
                enc = {k: v.to(device) for k, v in enc.items()}
                _ = model(**enc)
                if "x" in captured:
                    xs.append(captured["x"])
                    captured.pop("x")
    finally:
        h.remove()
    if not xs:
        return torch.randn(4, linear.in_features)
    return torch.cat(xs, dim=0)


def cmd_collect_stats(args) -> int:
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("collect_stats", run_dir / "logs")
    sens_path = run_dir / "compensation" / "layer_sensitivity.csv"
    _guard_overwrite(sens_path, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would collect stats -> {sens_path}")
        return 0
    _verify_lock(cfg, run_dir, log)
    from transformers import AutoTokenizer, AutoModelForCausalLM
    from .awq_integration import load_awq_model, collect_awq_linear_layers
    log.info("Loading FP16 + AWQ models for sensitivity")
    mid = cfg["model"]["model_id"]
    tok = AutoTokenizer.from_pretrained(mid, revision=cfg["model"]["tokenizer_revision"],
                                        trust_remote_code=True)
    fp_model = AutoModelForCausalLM.from_pretrained(
        mid, revision=cfg["model"]["revision"],
        dtype=getattr(torch, cfg["hardware"]["dtype"], torch.float16),
        trust_remote_code=True,
    ).to(cfg["hardware"]["device"])
    fp_model.eval()
    awq_model = load_awq_model(run_dir / "baseline" / "awq_checkpoint", cfg["hardware"]["device"])
    awq_layers = collect_awq_linear_layers(awq_model)
    entries, _activations = _compute_sensitivity(fp_model, tok, awq_layers, cfg, run_dir, log)
    rank_default = max(cfg["compensation"]["ranks"])
    selected = select_top_fraction(entries, max(cfg["compensation"]["layer_fractions"]), rank_default, min_improvement_ratio=0.001)
    write_sensitivity_csv(selected, sens_path)
    log.info("Wrote sensitivity for %d layers -> %s", len(selected), sens_path)
    del fp_model, awq_model
    torch.cuda.empty_cache()
    return 0


def cmd_build_compensation(args) -> int:
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("build_compensation", run_dir / "logs")
    method = args.method
    rank = int(args.rank)
    fraction = float(args.layer_fraction)
    adapter_dir = run_dir / "compensation" / "adapters" / f"{method}_r{rank}_f{fraction}"
    _guard_overwrite(adapter_dir, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would build {method} r{rank} f{fraction} -> {adapter_dir}")
        return 0
    _verify_lock(cfg, run_dir, log)
    from transformers import AutoTokenizer, AutoModelForCausalLM
    from .awq_integration import load_awq_model, collect_awq_linear_layers, dequantize_awq_layer
    log.info("Building compensation method=%s rank=%d fraction=%.2f", method, rank, fraction)
    mid = cfg["model"]["model_id"]
    tok = AutoTokenizer.from_pretrained(mid, revision=cfg["model"]["tokenizer_revision"],
                                        trust_remote_code=True)
    fp_model = AutoModelForCausalLM.from_pretrained(
        mid, revision=cfg["model"]["revision"],
        dtype=getattr(torch, cfg["hardware"]["dtype"], torch.float16),
        trust_remote_code=True,
    ).to(cfg["hardware"]["device"])
    fp_model.eval()
    awq_model = load_awq_model(run_dir / "baseline" / "awq_checkpoint", cfg["hardware"]["device"])
    awq_layers = collect_awq_linear_layers(awq_model)
    entries, activations = _compute_sensitivity(fp_model, tok, awq_layers, cfg, run_dir, log)
    selected = select_top_fraction(entries, fraction, rank, min_improvement_ratio=0.001)
    write_sensitivity_csv(selected, run_dir / "compensation" / "layer_sensitivity.csv")
    adapter_dir.mkdir(parents=True, exist_ok=True)
    reg = cfg["compensation"]["regularization"]
    comp_manifest = {"method": method, "rank": rank, "layer_fraction": fraction,
                     "selected_layers": [], "regularization": reg}
    for e in selected:
        if not e.selected:
            continue
        fp_lin = dict(fp_model.named_modules())[e.module_name]
        awq_mod = awq_layers[e.module_name]
        W = fp_lin.weight.detach().to(torch.float32).cpu()
        Q = dequantize_awq_layer(awq_mod).to(torch.float32).cpu()
        E = W - Q
        X = activations.get(e.module_name)
        if X is None:
            X = _collect_input_activations(fp_model, tok, e.module_name, fp_lin,
                                           _load_texts(cfg["data"]["calibration_path"], cfg["data"]["text_field"]),
                                           cfg, log).cpu()
        if method == "svd":
            adapter, rel = svd_compensate(E, rank)
        elif method == "activation_weighted":
            adapter, rel = activation_weighted_compensate(E, X, rank, reg)
        elif method == "qcomp":
            adapter, rel = build_layer_adapter(
                X, E, rank=rank, alpha=1.0, name=e.module_name)
        else:
            raise SystemExit(f"Unknown method: {method}")
        adapter.module_name = e.module_name
        layer_dir = adapter_dir / e.module_name.replace(".", "__")
        save_adapter(adapter, layer_dir, extra={"relative_residual": rel,
                                                "in_features": e.in_features,
                                                "out_features": e.out_features})
        comp_manifest["selected_layers"].append({
            "module_name": e.module_name, "relative_residual": rel,
            "param_count": adapter.param_count,
        })
        log.info("Compensated %s rel_residual=%.4f", e.module_name, rel)
    with open(adapter_dir / "compensation_manifest.json", "w", encoding="utf-8") as f:
        json.dump(comp_manifest, f, indent=2, ensure_ascii=False, default=str)
    log.info("Saved adapter -> %s", adapter_dir)
    print(str(adapter_dir))
    del fp_model, awq_model
    torch.cuda.empty_cache()
    return 0


def _load_adapters(adapter_path: Path) -> dict[str, LowRankAdapter]:
    adapters = {}
    for layer_dir in sorted(adapter_path.iterdir()):
        if not layer_dir.is_dir():
            continue
        cfg_file = layer_dir / "adapter_config.json"
        if not cfg_file.exists():
            continue
        ac = json.loads(cfg_file.read_text())
        adapter = load_adapter(layer_dir)
        adapter.module_name = ac["module_name"]
        adapters[ac["module_name"]] = adapter
    return adapters


def cmd_eval_comp_ppl(args) -> int:
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("eval_comp_ppl", run_dir / "logs")
    adapter_path = Path(args.adapter)
    tag = adapter_path.name
    out_path = run_dir / "results" / f"compensated_ppl_{tag}.json"
    _guard_overwrite(out_path, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would eval comp PPL -> {out_path}")
        return 0
    _verify_lock(cfg, run_dir, log)
    from .awq_integration import load_awq_model, apply_compensation_to_awq
    from transformers import AutoTokenizer
    log.info("Loading AWQ model + applying adapter %s", adapter_path)
    ckpt_dir = run_dir / "baseline" / "awq_checkpoint"
    tok = AutoTokenizer.from_pretrained(str(ckpt_dir), trust_remote_code=True)
    model = load_awq_model(ckpt_dir, cfg["hardware"]["device"])
    adapters = _load_adapters(adapter_path)
    n = apply_compensation_to_awq(model, adapters)
    log.info("Applied %d adapters", n)
    model.model.eval()
    total_nll, total_tokens, n_samples = _compute_ppl(model.model, tok, cfg, log)
    ppl = ppl_from_nll(total_nll, total_tokens)
    res = PPLResult(total_nll, total_tokens, n_samples, ppl,
                    cfg["model"]["model_id"], cfg["model"]["revision"])
    save_ppl(res, out_path)
    log.info("Comp PPL = %.4f", ppl)
    del model
    torch.cuda.empty_cache()
    return 0


def cmd_benchmark_comp(args) -> int:
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("benchmark_comp", run_dir / "logs")
    adapter_path = Path(args.adapter)
    tag = adapter_path.name
    out_path = run_dir / "results" / f"compensated_benchmark_{tag}.json"
    raw_path = run_dir / "results" / f"compensated_raw_requests_{tag}.jsonl"
    _guard_overwrite(out_path, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would benchmark comp -> {out_path}")
        return 0
    _verify_lock(cfg, run_dir, log)
    from .awq_integration import load_awq_model
    from transformers import AutoTokenizer
    ckpt_dir = run_dir / "baseline" / "awq_checkpoint"
    tok = AutoTokenizer.from_pretrained(str(ckpt_dir), trust_remote_code=True)
    model = load_awq_model(ckpt_dir, cfg["hardware"]["device"])
    adapters = _load_adapters(adapter_path)
    device = cfg["hardware"]["device"]
    results = _run_benchmarks(model.model, tok, cfg, log, device, adapters=adapters)
    _save_benchmark(results, out_path, raw_path)
    del model
    torch.cuda.empty_cache()
    return 0


def cmd_summarize(args) -> int:
    run_dir = Path(args.run_dir)
    log = setup_logger("summarize", run_dir / "logs")
    if args.dry_run:
        print(f"[dry-run] would summarize {run_dir}")
        return 0
    base = run_dir / "baseline"
    fp16 = load_ppl(base / "fp16_ppl.json")
    awq = load_ppl(base / "awq_ppl.json")
    d_awq = ppl_delta(fp16.ppl, awq.ppl)
    results_dir = run_dir / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    candidates = []
    if results_dir.exists():
        for p in sorted(results_dir.glob("compensated_ppl_*.json")):
            tag = p.stem.replace("compensated_ppl_", "")
            comp = load_ppl(p)
            bm_path = results_dir / f"compensated_benchmark_{tag}.json"
            awq_bm_path = base / "awq_benchmark.json"
            awq_out_tps = 0.0
            comp_out_tps = 0.0
            if awq_bm_path.exists():
                awq_bm = json.loads(awq_bm_path.read_text())
                awq_out_tps = _median_out_tps(awq_bm)
            if bm_path.exists():
                comp_bm = json.loads(bm_path.read_text())
                comp_out_tps = _median_out_tps(comp_bm)
            d_comp = ppl_delta(fp16.ppl, comp.ppl)
            reduction = ppl_degradation_reduction(d_awq, d_comp)
            retention = compute_throughput_retention(comp_out_tps, awq_out_tps) if awq_out_tps > 0 else 0.0
            status = "INCONCLUSIVE" if isinstance(reduction, str) else (
                "PASS" if (comp.ppl <= awq.ppl and (reduction if isinstance(reduction, float) else 0) >= 0.02
                          and retention >= 0.85) else "FAIL")
            candidates.append({
                "tag": tag, "ppl_comp": comp.ppl, "d_comp": d_comp,
                "ppl_degradation_reduction": reduction,
                "output_tokens_per_second": comp_out_tps,
                "throughput_retention": retention, "status": status,
            })
    with open(results_dir / "candidates.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["tag", "ppl_comp", "d_comp",
                                          "ppl_degradation_reduction",
                                          "output_tokens_per_second",
                                          "throughput_retention", "status"])
        w.writeheader()
        for c in candidates:
            w.writerow(c)
    env = json.loads((run_dir / "environment.json").read_text()) if (run_dir / "environment.json").exists() else {}
    a10_ok = env.get("a10_check_passed", False)
    best = None
    for c in candidates:
        if c["status"] == "PASS":
            best = c
            break
    final_status = "BLOCKED" if not a10_ok else (
        best["status"] if best else (
            "INCONCLUSIVE" if d_awq <= 1e-12 else (
                "FAIL" if candidates else "BLOCKED")))
    acceptance = {
        "ppl_fp16": fp16.ppl, "ppl_awq": awq.ppl, "d_awq": d_awq,
        "candidates": candidates, "final_status": final_status,
        "a10": a10_ok,
    }
    with open(results_dir / "acceptance.json", "w", encoding="utf-8") as f:
        json.dump(acceptance, f, indent=2, ensure_ascii=False, default=str)
    lines = ["# Two-Stage AWQ Compensation Report", "",
             f"- FP16 PPL: {fp16.ppl:.4f}",
             f"- AWQ PPL: {awq.ppl:.4f}",
             f"- d_awq: {d_awq:.6f}", "",
             "## Candidates", ""]
    for c in candidates:
        lines.append(f"- {c['tag']}: PPL={c['ppl_comp']:.4f} reduction={c['ppl_degradation_reduction']} "
                     f"retention={c['throughput_retention']:.3f} status={c['status']}")
    lines += ["", f"## Final status: {final_status}", ""]
    (results_dir / "report.md").write_text("\n".join(lines), encoding="utf-8")
    log.info("Summary written -> %s", results_dir)
    print(json.dumps(acceptance, indent=2, default=str))
    return 0


def _median_out_tps(bm: dict) -> float:
    wls = bm.get("workloads", [])
    vals = [w.get("output_tokens_per_second", 0.0) for w in wls if not w.get("oom")]
    if not vals:
        return 0.0
    return statistics.median(vals)


def cmd_qcomp_ppl_alpha_search(args) -> int:
    """PPL-based alpha search: for each alpha, eval PPL, pick the best.

    Loads adapter, iterates alpha grid, evaluates PPL for each, picks
    the alpha with the lowest PPL.  Saves a JSON summary.
    """
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("qcomp_ppl_alpha_search", run_dir / "logs")
    adapter_path = Path(args.adapter)
    tag = adapter_path.name
    alphas = [float(a) for a in args.alphas.split(",")]
    eval_path = getattr(args, "eval_path", None)
    max_samples = getattr(args, "max_samples", None)
    out_path = run_dir / "results" / f"qcomp_alpha_search_{tag}.json"
    _guard_overwrite(out_path, args.overwrite)
    if args.dry_run:
        print(f"[dry-run] would search alpha for {tag} alphas={alphas}")
        return 0
    from .awq_integration import load_awq_model, apply_compensation_to_awq
    from transformers import AutoTokenizer
    ckpt_dir = run_dir / "baseline" / "awq_checkpoint"
    tok = AutoTokenizer.from_pretrained(str(ckpt_dir), trust_remote_code=True)
    results = []
    for alpha in alphas:
        model = load_awq_model(ckpt_dir, cfg["hardware"]["device"])
        adapters = _load_qcomp_adapters(adapter_path)
        for name, adapter in adapters.items():
            adapter.alpha = alpha
        n = apply_compensation_to_awq(model, adapters)
        log.info("alpha=%.4f applied %d adapters", alpha, n)
        model.model.eval()
        total_nll, total_tokens, _ = _compute_ppl(
            model.model, tok, cfg, log, max_samples=max_samples, eval_path=eval_path)
        ppl = ppl_from_nll(total_nll, total_tokens)
        results.append({"alpha": alpha, "ppl": ppl, "nll": total_nll, "tokens": total_tokens})
        log.info("alpha=%.4f PPL=%.4f", alpha, ppl)
        print(f"  alpha={alpha:.4f}  PPL={ppl:.4f}")
        del model
        torch.cuda.empty_cache()
    results.sort(key=lambda r: r["ppl"])
    best = results[0]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({"tag": tag, "adapter": str(adapter_path), "best_alpha": best["alpha"],
                   "best_ppl": best["ppl"], "all_results": results}, f, indent=2, ensure_ascii=False)
    awq_ppl_path = run_dir / "baseline" / "awq_ppl.json"
    awq_ppl = None
    if awq_ppl_path.exists():
        awq_ppl = load_ppl(awq_ppl_path).ppl
    print(f"[qcomp-ppl-alpha-search] best alpha={best['alpha']:.4f} PPL={best['ppl']:.4f}")
    if awq_ppl:
        delta = best["ppl"] - awq_ppl
        rel = delta / awq_ppl if awq_ppl > 0 else float("nan")
        print(f"[qcomp-ppl-alpha-search] AWQ PPL={awq_ppl:.4f} delta={delta:+.4f} ({rel*100:+.2f}%)")
    return 0


def cmd_qcomp_search(args) -> int:
    """Run a guided QComp search: build adapter, PPL-alpha search, log to CSV.

    Combines build-qcomp-single + qcomp-ppl-alpha-search for a given layer/rank/lambda,
    and appends results to results/qcomp_search.csv.
    """
    import subprocess
    cfg = _load_cfg(args)
    run_dir = _artifacts_dir(cfg)
    log = setup_logger("qcomp_search", run_dir / "logs")
    layer = args.layer
    rank = int(args.rank)
    ridge_lambda = float(args.ridge_lambda)
    calib_path = args.calib_path or cfg["data"]["calibration_path"]
    val_path = args.val_path
    eval_path = args.eval_path or cfg["data"]["ppl_eval_path"]
    max_texts = int(args.max_texts)
    max_samples = getattr(args, "max_samples", None)
    alphas = args.alphas or "0.05,0.1,0.2,0.5,0.75,1.0"
    lam_tag = f"_lam{ridge_lambda}".replace(".", "p")
    adapter_dir = run_dir / "qcomp" / f"single_{layer.split('.')[-2]}_r{rank}{lam_tag}"
    log.info("qcomp-search: layer=%s rank=%d lambda=%s calib=%s val=%s eval=%s",
             layer, rank, ridge_lambda, calib_path, val_path, eval_path)
    # Step 1: build
    build_cmd = [
        sys.executable, "-m", "a10_quant_comp.cli", "build-qcomp-single",
        "--config", args.config, "--rank", str(rank), "--layer", layer,
        "--max-texts", str(max_texts), "--ridge-lambda", str(ridge_lambda),
        "--calib-path", calib_path,
    ]
    if val_path:
        build_cmd += ["--val-path", val_path]
    if adapter_dir.exists():
        build_cmd += ["--overwrite"]
    log.info("Building adapter...")
    subprocess.run(build_cmd, check=True)
    # Step 2: PPL-based alpha search
    search_cmd = [
        sys.executable, "-m", "a10_quant_comp.cli", "qcomp-ppl-alpha-search",
        "--config", args.config, "--adapter", str(adapter_dir),
        "--alphas", alphas, "--eval-path", eval_path,
    ]
    if max_samples:
        search_cmd += ["--max-samples", str(max_samples)]
    if args.overwrite:
        search_cmd += ["--overwrite"]
    log.info("Searching alpha by PPL...")
    subprocess.run(search_cmd, check=True)
    # Step 3: read best result and log to CSV
    search_json = run_dir / "results" / f"qcomp_alpha_search_{adapter_dir.name}.json"
    with open(search_json) as f:
        search_res = json.load(f)
    best_alpha = search_res["best_alpha"]
    best_ppl = search_res["best_ppl"]
    awq_ppl_path = run_dir / "baseline" / "awq_ppl.json"
    awq_ppl = load_ppl(awq_ppl_path).ppl if awq_ppl_path.exists() else None
    delta_pct = ((best_ppl - awq_ppl) / awq_ppl * 100) if awq_ppl else float("nan")
    csv_path = Path("results/qcomp_search.csv")
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    header = ["layer", "rank", "lambda", "alpha", "PPL", "PPL_delta"]
    row = [layer, str(rank), str(ridge_lambda), f"{best_alpha:.4f}",
           f"{best_ppl:.4f}", f"{delta_pct:+.2f}%"]
    write_header = not csv_path.exists()
    with open(csv_path, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if write_header:
            w.writerow(header)
        w.writerow(row)
    log.info("Logged to %s: %s", csv_path, row)
    print(f"[qcomp-search] layer={layer} rank={rank} lambda={ridge_lambda} "
          f"alpha={best_alpha:.4f} PPL={best_ppl:.4f} delta={delta_pct:+.2f}%")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="a10_quant_comp.cli", description="Two-stage AWQ compensation")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="command", required=True)

    def add_common(sp):
        sp.add_argument("--config", required=True)
        sp.add_argument("--dry-run", action="store_true")
        sp.add_argument("--overwrite", action="store_true")

    sp = sub.add_parser("check-env", help="Check A10/CUDA/PyTorch environment")
    add_common(sp); sp.set_defaults(func=cmd_check_env)

    sp = sub.add_parser("eval-fp16-ppl", help="Compute FP16 PPL")
    add_common(sp); sp.set_defaults(func=cmd_eval_fp16_ppl)

    sp = sub.add_parser("quantize-awq", help="Quantize model to AWQ W4A16 via AutoAWQ")
    add_common(sp); sp.set_defaults(func=cmd_quantize_awq)

    sp = sub.add_parser("eval-awq-ppl", help="Compute AWQ PPL")
    add_common(sp); sp.set_defaults(func=cmd_eval_awq_ppl)

    sp = sub.add_parser("benchmark-awq", help="Benchmark AWQ throughput/latency")
    add_common(sp); sp.set_defaults(func=cmd_benchmark_awq)

    sp = sub.add_parser("freeze-baseline", help="Freeze AWQ baseline lock")
    add_common(sp); sp.set_defaults(func=cmd_freeze_baseline)

    sp = sub.add_parser("collect-stats", help="Collect layer sensitivity stats")
    add_common(sp); sp.set_defaults(func=cmd_collect_stats)

    sp = sub.add_parser("build-compensation", help="Build low-rank compensation adapter")
    add_common(sp)
    sp.add_argument("--method", required=True, choices=["svd", "activation_weighted", "qcomp"])
    sp.add_argument("--rank", required=True, type=int)
    sp.add_argument("--layer-fraction", required=True, type=float)
    sp.set_defaults(func=cmd_build_compensation)

    sp = sub.add_parser("eval-comp-ppl", help="Evaluate compensated PPL")
    add_common(sp)
    sp.add_argument("--adapter", required=True)
    sp.set_defaults(func=cmd_eval_comp_ppl)

    sp = sub.add_parser("benchmark-comp", help="Benchmark compensated model")
    add_common(sp)
    sp.add_argument("--adapter", required=True)
    sp.set_defaults(func=cmd_benchmark_comp)

    sp = sub.add_parser("summarize", help="Summarize results and judge acceptance")
    sp.add_argument("--run-dir", required=True)
    sp.add_argument("--dry-run", action="store_true")
    sp.set_defaults(func=cmd_summarize)

    sp = sub.add_parser("build-qcomp", help="Build QComp A/B adapter for a single layer")
    add_common(sp)
    sp.add_argument("--rank", required=True, type=int)
    sp.set_defaults(func=cmd_build_qcomp)

    sp = sub.add_parser("eval-qcomp-ppl", help="Evaluate AWQ+QComp PPL")
    add_common(sp)
    sp.add_argument("--adapter", required=True)
    sp.add_argument("--alpha-override", type=float, default=None,
                    help="Override adapter alpha at eval time (no rebuild needed)")
    sp.add_argument("--max-samples", type=int, default=None,
                    help="Limit eval to first N texts")
    sp.add_argument("--eval-path", type=str, default=None,
                    help="Override eval data path (default: cfg data.ppl_eval_path)")
    sp.set_defaults(func=cmd_eval_qcomp_ppl)

    sp = sub.add_parser("score-qcomp-layers", help="Score candidate layers for QComp (Task 1)")
    add_common(sp)
    sp.add_argument("--rank", type=int, default=8)
    sp.add_argument("--calib-path", type=str, default=None)
    sp.add_argument("--max-texts", type=int, default=64)
    sp.add_argument("--ridge-lambda", type=float, default=1e-2)
    sp.set_defaults(func=cmd_score_qcomp_layers)

    sp = sub.add_parser("build-qcomp-multi", help="Build multi-layer QComp adapters (Task 2+3)")
    add_common(sp)
    sp.add_argument("--num-layers", type=int, required=True)
    sp.add_argument("--rank", type=int, default=8)
    sp.add_argument("--ridge-lambda", type=float, default=1e-2)
    sp.add_argument("--calib-path", type=str, default=None)
    sp.add_argument("--val-path", type=str, default=None)
    sp.add_argument("--max-texts", type=int, default=64)
    sp.set_defaults(func=cmd_build_qcomp_multi)

    sp = sub.add_parser("build-qcomp-single", help="Build single-layer QComp (output-space, ridge)")
    add_common(sp)
    sp.add_argument("--rank", type=int, default=8)
    sp.add_argument("--layer", type=str, default="model.layers.2.mlp.down_proj")
    sp.add_argument("--max-texts", type=int, default=64)
    sp.add_argument("--ridge-lambda", type=float, default=1e-2,
                    help="Ridge regression regularization lambda")
    sp.add_argument("--calib-path", type=str, default=None,
                    help="Override calibration data path")
    sp.add_argument("--val-path", type=str, default=None,
                    help="Validation data path for alpha search (default: 50/50 split)")
    sp.set_defaults(func=cmd_build_qcomp_single)

    sp = sub.add_parser("benchmark-qcomp", help="Benchmark AWQ+QComp throughput (Task 5)")
    add_common(sp)
    sp.add_argument("--adapter", required=True)
    sp.set_defaults(func=cmd_benchmark_qcomp)

    sp = sub.add_parser("qcomp-ppl-alpha-search", help="PPL-based alpha search")
    add_common(sp)
    sp.add_argument("--adapter", required=True)
    sp.add_argument("--alphas", type=str, default="0.05,0.1,0.2,0.5,0.75,1.0",
                    help="Comma-separated alpha values to search")
    sp.add_argument("--max-samples", type=int, default=None)
    sp.add_argument("--eval-path", type=str, default=None)
    sp.set_defaults(func=cmd_qcomp_ppl_alpha_search)

    sp = sub.add_parser("qcomp-search", help="Guided QComp search (build + alpha search + log)")
    add_common(sp)
    sp.add_argument("--rank", type=int, required=True)
    sp.add_argument("--layer", type=str, default="model.layers.0.mlp.down_proj")
    sp.add_argument("--ridge-lambda", type=float, default=1e-2)
    sp.add_argument("--max-texts", type=int, default=80)
    sp.add_argument("--calib-path", type=str, default=None)
    sp.add_argument("--val-path", type=str, default=None)
    sp.add_argument("--eval-path", type=str, default=None)
    sp.add_argument("--max-samples", type=int, default=None)
    sp.add_argument("--alphas", type=str, default=None)
    sp.set_defaults(func=cmd_qcomp_search)

    return p


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except SystemExit:
        raise
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
