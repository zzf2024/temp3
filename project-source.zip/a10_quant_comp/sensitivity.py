"""Sensitivity analysis: rank linear layers by AWQ output error."""
from __future__ import annotations

import csv
import math
from dataclasses import dataclass
from pathlib import Path

import torch

from .compensation import EPS


def relative_output_error(X: torch.Tensor, W: torch.Tensor, Q: torch.Tensor) -> tuple[float, float]:
    """e_awq = ||XW^T - XQ^T||_F / max(||XW^T||_F, eps). Returns (rel_err, residual_norm)."""
    y_orig = X.float() @ W.t()
    y_quant = X.float() @ Q.t()
    diff = y_orig - y_quant
    num = torch.linalg.norm(diff, ord="fro")
    den = torch.linalg.norm(y_orig, ord="fro").clamp(min=EPS)
    return float((num / den).item()), float(num.item())


@dataclass
class LayerSensitivity:
    module_name: str
    in_features: int
    out_features: int
    relative_output_error: float
    residual_norm: float
    sensitivity_rank: int
    selected: bool
    compensation_rank: int
    adapter_param_count: int
    _improvement_ratio: float = 0.0  # (before-after)/before; >0 means compensation helps


def compute_output_error_improvement(X: torch.Tensor, W: torch.Tensor, Q: torch.Tensor, rank: int, method: str = "svd", regularization: float = 1e-5) -> tuple[float, float]:
    """Compute (before, after) output error for a candidate layer.
    Returns (error_before, error_after). Used to filter layers where
    compensation actually reduces the activation-weighted output error."""
    from .compensation import svd_compensate, activation_weighted_compensate
    E = W - Q
    if method == "svd":
        adapter, _ = svd_compensate(E, rank)
    else:
        adapter, _ = activation_weighted_compensate(E, X, rank, regularization)
    delta = adapter.delta()
    before = float(torch.linalg.norm(X @ E.t(), "fro").item())
    after = float(torch.linalg.norm(X @ (E - delta).t(), "fro").item())
    return before, after


def select_top_fraction(
    entries: list[LayerSensitivity],
    fraction: float,
    rank: int,
    min_improvement_ratio: float = 0.0,
    max_relative_error: float = 0.5,
) -> list[LayerSensitivity]:
    """Select top-fraction layers by sensitivity.

    A layer is selected only if ALL of:
      - it is in the top-fraction by relative output error
      - its compensation improves output error (improvement_ratio > threshold)
      - its relative output error is below max_relative_error (skips layers
        with extreme quantization error where rank-r compensation cannot
        help and the large delta amplifies model-level error)
    """
    n = len(entries)
    # First filter to viable candidates: improvement > threshold and
    # relative error within controllable range.
    viable = [
        e for e in entries
        if e._improvement_ratio > min_improvement_ratio
        and e.relative_output_error <= max_relative_error
    ]
    n_target = max(1, math.ceil(n * fraction))
    n_target = min(n_target, len(viable)) if viable else 0
    # Sort viable by absolute output-error improvement (before * ratio),
    # which favors layers where compensation removes the most error.
    viable_sorted = sorted(
        viable,
        key=lambda e: e.residual_norm * e._improvement_ratio,
        reverse=True,
    )
    selected_names = {e.module_name for e in viable_sorted[:n_target]}
    # Rank ALL entries by relative_output_error for the CSV sensitivity_rank
    sorted_all = sorted(entries, key=lambda e: e.relative_output_error, reverse=True)
    out: list[LayerSensitivity] = []
    for i, e in enumerate(sorted_all):
        sel = e.module_name in selected_names
        comp_rank = rank if sel else 0
        params = (e.out_features + e.in_features) * comp_rank
        out.append(
            LayerSensitivity(
                module_name=e.module_name,
                in_features=e.in_features,
                out_features=e.out_features,
                relative_output_error=e.relative_output_error,
                residual_norm=e.residual_norm,
                sensitivity_rank=i + 1,
                selected=sel,
                compensation_rank=comp_rank,
                adapter_param_count=params,
                _improvement_ratio=e._improvement_ratio,
            )
        )
    return out


def write_sensitivity_csv(entries: list[LayerSensitivity], path: str | Path) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "module_name", "in_features", "out_features",
        "relative_output_error", "residual_norm",
        "sensitivity_rank", "selected", "compensation_rank", "adapter_param_count",
    ]
    with open(p, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for e in entries:
            w.writerow({k: getattr(e, k) for k in fields})
