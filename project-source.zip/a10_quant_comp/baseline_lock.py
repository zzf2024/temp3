"""Baseline lock generation and integrity verification."""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Optional


@dataclass
class BaselineLock:
    model_id: str
    revision: Optional[str]
    tokenizer_revision: Optional[str]
    awq_checkpoint_path: Optional[str]
    awq_checkpoint_hash: Optional[str]
    awq_config: dict
    ppl_data_hash: str
    benchmark_workload_hash: str
    serving_config: dict
    git_commit: Optional[str]
    extra: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


def save_lock(lock: BaselineLock, path: str | Path) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(lock.to_dict(), f, indent=2, ensure_ascii=False, default=str)


def load_lock(path: str | Path) -> BaselineLock:
    with open(path, "r", encoding="utf-8") as f:
        d = json.load(f)
    return BaselineLock(**d)


def verify_lock(lock: BaselineLock, current: dict[str, Any]) -> list[str]:
    """Return list of violations; empty means OK.

    current keys mirror stage-2 immutables: model_id, revision,
    tokenizer_revision, awq_checkpoint_path, awq_config, ppl_data_hash,
    benchmark_workload_hash, serving_config, git_commit.
    """
    violations: list[str] = []
    checks = [
        ("model_id", lock.model_id, current.get("model_id")),
        ("revision", lock.revision, current.get("revision")),
        ("tokenizer_revision", lock.tokenizer_revision, current.get("tokenizer_revision")),
        ("awq_checkpoint_path", lock.awq_checkpoint_path, current.get("awq_checkpoint_path")),
        ("awq_config", lock.awq_config, current.get("awq_config")),
        ("ppl_data_hash", lock.ppl_data_hash, current.get("ppl_data_hash")),
        ("benchmark_workload_hash", lock.benchmark_workload_hash, current.get("benchmark_workload_hash")),
        ("serving_config", lock.serving_config, current.get("serving_config")),
        ("git_commit", lock.git_commit, current.get("git_commit")),
    ]
    for name, locked, cur in checks:
        if locked != cur:
            violations.append(f"{name} changed: {locked!r} -> {cur!r}")
    return violations
