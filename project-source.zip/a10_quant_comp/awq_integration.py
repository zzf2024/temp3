"""AutoAWQ integration: quantize, load, dequantize, and run AWQ models on A10."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

import torch


def _suppress_awq_warnings():
    import warnings
    warnings.filterwarnings("ignore", category=DeprecationWarning)


def quantize_model(
    model_id: str,
    output_dir: str | Path,
    calibration_texts: list[str],
    bits: int = 4,
    group_size: int = 128,
    revision: Optional[str] = None,
    tokenizer_revision: Optional[str] = None,
) -> str:
    """Quantize a HF model with AutoAWQ and save to output_dir."""
    _suppress_awq_warnings()
    from awq.models.auto import AutoAWQForCausalLM
    from transformers import AutoTokenizer

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    tok = AutoTokenizer.from_pretrained(model_id, revision=tokenizer_revision, trust_remote_code=True)
    model = AutoAWQForCausalLM.from_pretrained(
        model_id, device_map="cuda:0", dtype=torch.float16, trust_remote_code=True,
        revision=revision,
    )
    model.quantize(
        tok,
        quant_config={
            "zero_point": True,
            "q_group_size": group_size,
            "w_bit": bits,
            "version": "GEMM",
        },
        calib_data=calibration_texts,
    )
    model.save_quantized(str(output_dir))
    tok.save_pretrained(str(output_dir))
    return str(output_dir)


def load_awq_model(checkpoint_dir: str | Path, device: str = "cuda:0"):
    """Load a quantized AutoAWQ model (unfused) for reference inference."""
    _suppress_awq_warnings()
    from awq.models.auto import AutoAWQForCausalLM
    model = AutoAWQForCausalLM.from_quantized(
        str(checkpoint_dir), device=device, fuse_layers=False, trust_remote_code=True,
    )
    return model


def dequantize_awq_layer(awq_module) -> torch.Tensor:
    """Dequantize a WQLinear_GEMM module to FP16 weight [out_features, in_features]."""
    from awq.utils.packing_utils import dequantize_gemm
    qweight = awq_module.qweight
    qzeros = awq_module.qzeros
    scales = awq_module.scales
    bits = awq_module.w_bit
    group_size = awq_module.group_size
    W = dequantize_gemm(qweight, qzeros, scales, bits, group_size)  # [in, out]
    return W.t().contiguous().to(torch.float16)  # [out, in]


def collect_awq_linear_layers(awq_model) -> dict[str, object]:
    """Return {module_name: WQLinear_GEMM} for all quantized linear layers."""
    out = {}
    for name, mod in awq_model.model.named_modules():
        if hasattr(mod, "qweight"):
            out[name] = mod
    return out


def apply_compensation_to_awq(awq_model, adapters: dict[str, object]) -> int:
    """Apply low-rank delta to AWQ layers by replacing the forward weight.

    Since WQLinear_GEMM packs int4 weights, we cannot directly add a float delta
    to qweight. Instead we attach a compensation attribute and monkey-patch
    forward to add X @ delta^T after the quantized matmul.

    Two factor layouts are supported:
      - materialised delta (default): adapter.delta() -> [out, in]
      - factorised A/B (QComp MVP): adapter.A [out, rank], adapter.B [rank, in]
        The forward applies X @ B^T @ A^T without materialising A@B.
    Returns number of layers compensated.
    """
    n = 0
    for name, mod in awq_model.model.named_modules():
        if hasattr(mod, "qweight") and name in adapters:
            adapter = adapters[name]
            if hasattr(adapter, "A") and hasattr(adapter, "B") and not hasattr(adapter, "delta"):
                mod._qcomp_A = adapter.A.to(torch.float16).to(mod.qweight.device)
                mod._qcomp_B = adapter.B.to(torch.float16).to(mod.qweight.device)
                mod._qcomp_alpha = getattr(adapter, "alpha", 1.0)
                mod._comp_in_features = adapter.B.shape[1]
                mod._comp_out_features = adapter.A.shape[0]
                mod._comp_mode = "qcomp"
            elif hasattr(adapter, "A") and hasattr(adapter, "B") and hasattr(adapter, "delta"):
                # LowRankAdapter: materialise delta but also expose A/B.
                mod._comp_delta = adapter.delta().to(torch.float16).to(mod.qweight.device)
                mod._comp_in_features = adapter.in_features
                mod._comp_out_features = adapter.out_features
                mod._comp_mode = "delta"
            else:
                mod._comp_delta = adapter.delta().to(torch.float16).to(mod.qweight.device)
                mod._comp_in_features = adapter.in_features
                mod._comp_out_features = adapter.out_features
                mod._comp_mode = "delta"
            if not getattr(mod, "_comp_patched", False):
                _patch_forward(mod)
                mod._comp_patched = True
            n += 1
    return n


def _patch_forward(mod):
    """Monkey-patch a WQLinear_GEMM forward to add compensation.

    For ``_comp_mode == "qcomp"`` the correction is applied as the factorised
    product  alpha * X @ B^T @ A^T  (A@B is never materialised). Otherwise the
    materialised delta is used:  X @ delta^T.
    """
    original_forward = mod.forward

    def patched_forward(x, *args, **kwargs):
        out = original_forward(x, *args, **kwargs)
        x_h = x.to(torch.float16)
        if getattr(mod, "_comp_mode", "delta") == "qcomp":
            z = torch.nn.functional.linear(x_h, mod._qcomp_B)            # [*, rank]
            comp = torch.nn.functional.linear(z, mod._qcomp_A)           # [*, out]
            comp = comp * mod._qcomp_alpha
        else:
            comp = torch.nn.functional.linear(x_h, mod._comp_delta)      # [*, out]
        out = out + comp.to(out.dtype)
        return out

    mod.forward = patched_forward
