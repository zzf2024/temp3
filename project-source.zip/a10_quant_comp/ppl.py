"""Perplexity computation using total NLL / total valid tokens."""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional

import torch
import torch.nn.functional as F


@dataclass
class PPLResult:
    total_nll: float
    total_valid_tokens: int
    num_samples: int
    ppl: float
    model_id: Optional[str] = None
    revision: Optional[str] = None

    def to_dict(self):
        return asdict(self)


def ppl_from_nll(total_nll: float, total_valid_tokens: int) -> float:
    if total_valid_tokens <= 0:
        raise ValueError("total_valid_tokens must be positive")
    avg_nll = total_nll / total_valid_tokens
    return math.exp(avg_nll)


def ppl_from_logits(
    logits: torch.Tensor,
    labels: torch.Tensor,
    ignore_index: int = -100,
) -> tuple[float, int]:
    """Compute (total_nll, num_valid_tokens) for a batch.

    logits: [N, V] or [B, T, V]; labels: [N] or [B, T].
    """
    if logits.dim() == 3:
        logits = logits.reshape(-1, logits.size(-1))
        labels = labels.reshape(-1)
    elif logits.dim() != 2:
        raise ValueError(f"logits must be 2D or 3D, got {logits.dim()}D")
    if labels.dim() != 1:
        raise ValueError("labels must be 1D after flattening")
    if logits.size(0) != labels.size(0):
        raise ValueError(
            f"logits batch {logits.size(0)} != labels {labels.size(0)}"
        )
    mask = labels != ignore_index
    valid = mask.sum().item()
    if valid == 0:
        return 0.0, 0
    loss = F.cross_entropy(logits.float(), labels, reduction="sum", ignore_index=ignore_index)
    nll = float(loss.item())
    return nll, valid


def ppl_delta(ppl_a: float, ppl_b: float) -> float:
    """Relative degradation of b vs a: max((ppl_b-ppl_a)/ppl_a, 0)."""
    if ppl_a <= 0:
        raise ValueError("reference ppl must be positive")
    return max((ppl_b - ppl_a) / ppl_a, 0.0)


def ppl_degradation_reduction(d_awq: float, d_comp: float) -> float | str:
    """Return reduction ratio, or 'N/A' if d_awq is negligible."""
    if d_awq <= 1e-12:
        return "N/A"
    return (d_awq - d_comp) / max(d_awq, 1e-12)


def save_ppl(result: PPLResult, path: str | Path) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(result.to_dict(), f, indent=2, ensure_ascii=False)


def load_ppl(path: str | Path) -> PPLResult:
    with open(path, "r", encoding="utf-8") as f:
        d = json.load(f)
    return PPLResult(**d)
