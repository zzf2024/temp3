
import torch

def output_error_score(y_fp, y_awq):
    err = y_fp - y_awq
    return float(torch.norm(err).item()), err
