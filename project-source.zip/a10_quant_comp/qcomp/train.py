"""Fit low-rank A/B factors for activation-weighted error correction.

The factors are kept separate and A@B is never materialised: the factorised
forward pass applies the correction as X @ B^T @ A^T, which is cheaper in
memory when rank << min(out, in).
"""
from __future__ import annotations

import torch

from ..compensation import LowRankAdapter, EPS, _check_finite


def fit_qcomp_svd(
    x: torch.Tensor,
    error: torch.Tensor,
    rank: int = 8,
    alpha: float = 1.0,
    module_name: str = "",
    regularization: float = 1.0e-5,
) -> tuple[LowRankAdapter, float]:
    """Activation-weighted truncated SVD of *error*.

    Minimises ||X (E - AB)^T||_F^2 via diagonal second-moment weighting,
    then returns scaled factors (alpha*A, B) so the effective correction
    is alpha * A @ B.

    Returns (adapter, relative_residual) where relative_residual is the
    activation-weighted residual ||X(E-AB)^T||_F / ||X E^T||_F, computed
    in factorised form (A@B is never formed).
    """
    if error.dim() != 2:
        raise ValueError("error must be 2D")
    if x.dim() != 2:
        raise ValueError("x must be 2D")
    _check_finite(error, "error")
    _check_finite(x, "x")
    out_features, in_features = error.shape
    if x.size(-1) != in_features:
        raise ValueError(
            f"x in_features {x.size(-1)} != error in_features {in_features}"
        )
    rank = max(1, min(rank, min(out_features, in_features)))
    lam = float(regularization)
    h = (x.float() ** 2).mean(dim=0)  # [in]
    h = h.clamp(min=0.0) + lam
    R_diag = torch.sqrt(h)  # [in]
    E_w = error.float() * R_diag.unsqueeze(0)  # [out, in]
    U, S, Vh = torch.linalg.svd(E_w, full_matrices=False)
    A = (U[:, :rank] * S[:rank].unsqueeze(0)).contiguous()  # [out, rank]
    Bw = Vh[:rank, :].contiguous()  # [rank, in]
    R_inv = 1.0 / R_diag.clamp(min=EPS)
    B = Bw * R_inv.unsqueeze(0)  # [rank, in]
    A = A * alpha
    adapter = LowRankAdapter(A, B, "activation_weighted", rank, module_name)
    # factorised residual: X E^T  vs  X B^T A^T  (no [out,in] materialisation)
    XE_t = x.float() @ error.t()  # [N, out]
    XAB_t = (x.float() @ B.t()) @ A.t()  # [N, out]
    num = torch.linalg.norm(XE_t - XAB_t, ord="fro")
    ref = torch.linalg.norm(XE_t, ord="fro").clamp(min=EPS)
    rel = float((num / ref).item())
    return adapter, rel
