
from .train import fit_qcomp_svd

def build_layer_adapter(x, error, rank=8, alpha=1.0, name=""):
    return fit_qcomp_svd(
        x, error,
        rank=rank,
        alpha=alpha,
        module_name=name,
    )
