
def select_layers(scores, fraction=0.05):
    items = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    n = max(1, int(len(items)*fraction))
    return [k for k,_ in items[:n]]
