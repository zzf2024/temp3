"""QComp MVP: factorized A/B low-rank compensation (activation-weighted).

Fits error ~= X @ B^T @ A^T using activation-weighted truncated SVD so
that A and B are kept separate and A@B is never materialised at fit time
nor at forward time.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F


class QCompAdapter:
    """A [out, rank], B [rank, in]; correction = alpha * X @ B^T @ A^T."""

    def __init__(self, A: torch.Tensor, B: torch.Tensor, alpha: float = 1.0):
        self.A = A
        self.B = B
        self.alpha = alpha

    @property
    def out_features(self) -> int:
        return self.A.shape[0]

    @property
    def in_features(self) -> int:
        return self.B.shape[1]

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        z = F.linear(x, self.B)          # [*, rank]
        return self.alpha * F.linear(z, self.A)  # [*, out]


def fit_qcomp(X: torch.Tensor, error: torch.Tensor, rank: int = 8,
              alpha: float = 1.0, regularization: float = 1.0e-5) -> QCompAdapter:
    """Fit A, B such that  X @ B^T @ A^T  approximates  X @ error^T.

    Activation-weighted truncated SVD: weight columns of error by
    sqrt(mean(X^2, dim=0) + lambda), truncate to `rank`, then unweight B.
    """
    if error.dim() != 2:
        raise ValueError("error must be 2D [out, in]")
    if X.dim() != 2:
        raise ValueError("X must be 2D [N, in]")
    if X.size(-1) != error.size(-1):
        raise ValueError(f"X in_features {X.size(-1)} != error in_features {error.size(-1)}")

    out_features, in_features = error.shape
    rank = max(1, min(rank, min(out_features, in_features)))

    Xf = X.float()
    Ef = error.float()

    h = (Xf ** 2).mean(dim=0)                  # [in]
    R_diag = torch.sqrt(h.clamp(min=0.0) + regularization)  # [in]
    Ew = Ef * R_diag.unsqueeze(0)              # [out, in]

    U, S, Vh = torch.linalg.svd(Ew, full_matrices=False)
    A = (U[:, :rank] * S[:rank].unsqueeze(0)).contiguous()  # [out, rank]
    Bw = Vh[:rank, :].contiguous()             # [rank, in]
    B = Bw * (1.0 / R_diag.clamp(min=1e-12)).unsqueeze(0)   # [rank, in]

    # alpha is NOT baked into A; it is applied only at runtime in __call__
    return QCompAdapter(A, B, alpha=alpha)


def search_alpha(adapter: QCompAdapter, X: torch.Tensor, error: torch.Tensor,
                 alphas: list[float] | None = None) -> tuple[float, float]:
    """Find alpha minimising ||X error^T - alpha * X B^T A^T||_F.

    Returns (best_alpha, best_error_norm).  Does NOT mutate the adapter.
    The optimal alpha for a fixed (A, B) has a closed form, but we also
    evaluate a discrete grid so the caller can see the landscape.
    """
    if alphas is None:
        alphas = [0.25, 0.5, 0.75, 1.0]
    Xf = X.float()
    # Precompute: correction at alpha=1  ->  X @ B^T @ A^T  [N, out]
    z = Xf @ adapter.B.t()               # [N, rank]
    corr1 = z @ adapter.A.t()           # [N, out]
    target = Xf @ error.t()             # [N, out]
    # Closed-form optimal: alpha* = <target, corr1> / <corr1, corr1>
    num = float((target * corr1).sum().item())
    den = float((corr1 * corr1).sum().item())
    alpha_star = num / max(den, 1e-12)
    # Evaluate grid (plus closed-form)
    best_alpha = alpha_star
    best_err = float(torch.linalg.norm(target - alpha_star * corr1, "fro").item())
    for a in alphas:
        err = float(torch.linalg.norm(target - a * corr1, "fro").item())
        if err < best_err:
            best_err = err
            best_alpha = a
    return best_alpha, best_err


def fit_qcomp_output(X: torch.Tensor, target: torch.Tensor, rank: int = 8,
                     alpha: float = 1.0, regularization: float = 1.0e-2) -> QCompAdapter:
    """Fit A, B such that  X @ B^T @ A^T  approximates  target [N, out].

    Solves ridge regression: W_eff^T = (X^T X + lambda I)^{-1} X^T target
    -> [in, out], then applies activation-weighted truncated SVD on W_eff
    to obtain factorised A, B.
    """
    if X.dim() != 2:
        raise ValueError("X must be 2D [N, in]")
    if target.dim() != 2:
        raise ValueError("target must be 2D [N, out]")
    if X.size(0) != target.size(0):
        raise ValueError(f"X samples {X.size(0)} != target samples {target.size(0)}")

    out_features = target.size(-1)
    in_features = X.size(-1)
    rank = max(1, min(rank, min(out_features, in_features)))

    Xf = X.float()
    Tf = target.float()

    # Ridge regression: W_eff^T = (X^T X + lambda I)^{-1} X^T target
    XtX = Xf.t() @ Xf                         # [in, in]
    XtT = Xf.t() @ Tf                         # [in, out]
    ridge = regularization * torch.eye(in_features, dtype=Xf.dtype, device=Xf.device)
    W_eff_T = torch.linalg.solve(XtX + ridge, XtT)   # [in, out]
    W_eff = W_eff_T.t().contiguous()                    # [out, in]

    # Activation-weighted truncated SVD (same as fit_qcomp)
    h = (Xf ** 2).mean(dim=0)                                # [in]
    R_diag = torch.sqrt(h.clamp(min=0.0) + regularization)   # [in]
    Ew = W_eff * R_diag.unsqueeze(0)                         # [out, in]

    U, S, Vh = torch.linalg.svd(Ew, full_matrices=False)
    A = (U[:, :rank] * S[:rank].unsqueeze(0)).contiguous()   # [out, rank]
    Bw = Vh[:rank, :].contiguous()                           # [rank, in]
    B = Bw * (1.0 / R_diag.clamp(min=1e-12)).unsqueeze(0)    # [rank, in]

    return QCompAdapter(A, B, alpha=alpha)


def search_alpha_output(adapter: QCompAdapter, X: torch.Tensor, target: torch.Tensor,
                        alphas: list[float] | None = None) -> tuple[float, float]:
    """Find alpha minimising ||target - alpha * X B^T A^T||_F on validation data.

    target is [N, out] (output-space error). Returns (best_alpha, best_error_norm).
    Default grid: [0.05, 0.1, 0.2, 0.5, 0.75, 1.0].
    """
    if alphas is None:
        alphas = [0.05, 0.1, 0.2, 0.5, 0.75, 1.0]
    Xf = X.float()
    z = Xf @ adapter.B.t()               # [N, rank]
    corr1 = z @ adapter.A.t()            # [N, out]
    Tf = target.float()                  # [N, out]
    best_alpha = alphas[0]
    best_err = float("inf")
    for a in alphas:
        err = float(torch.linalg.norm(Tf - a * corr1, "fro").item())
        if err < best_err:
            best_err = err
            best_alpha = a
    return best_alpha, best_err


def save_qcomp_adapter(adapter: QCompAdapter, path, module_name: str = "",
                       extra: dict | None = None) -> None:
    """Save A, B, alpha to a directory in safetensors (fallback torch)."""
    import json
    from pathlib import Path
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    cfg = {
        "type": "qcomp",
        "module_name": module_name,
        "alpha": adapter.alpha,
        "out_features": adapter.out_features,
        "in_features": adapter.in_features,
    }
    if extra:
        cfg.update(extra)
    with open(p / "adapter_config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    try:
        from safetensors.torch import save_file
        save_file(
            {"A": adapter.A.contiguous().to(torch.float32),
             "B": adapter.B.contiguous().to(torch.float32)},
            str(p / "adapter_model.safetensors"),
        )
    except Exception:
        torch.save(
            {"A": adapter.A, "B": adapter.B},
            p / "adapter_model.pt",
        )


def load_qcomp_adapter(path) -> tuple[QCompAdapter, str]:
    """Load a QCompAdapter; returns (adapter, module_name)."""
    import json
    from pathlib import Path
    p = Path(path)
    with open(p / "adapter_config.json", "r", encoding="utf-8") as f:
        cfg = json.load(f)
    st = p / "adapter_model.safetensors"
    if st.exists():
        from safetensors.torch import load_file
        d = load_file(str(st))
    else:
        d = torch.load(p / "adapter_model.pt")
    adapter = QCompAdapter(d["A"], d["B"], alpha=cfg.get("alpha", 1.0))
    return adapter, cfg.get("module_name", "")
