"""Acceptance criteria and metric computation."""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Optional

from .ppl import ppl_delta, ppl_degradation_reduction


@dataclass
class WorkloadMetrics:
    input_token_length: int
    concurrency: int
    output_tokens_per_second: float
    total_tokens_per_second: float
    requests_per_second: float
    ttft_p50: float
    ttft_p95: float
    ttft_p99: float
    tpot_p50: float
    tpot_p95: float
    tpot_p99: float
    e2e_p50: float
    e2e_p95: float
    e2e_p99: float
    peak_gpu_memory_mb: float = 0.0


@dataclass
class AcceptanceResult:
    ppl_fp16: float
    ppl_awq: float
    ppl_comp: float
    d_awq: float
    d_comp: float
    ppl_degradation_reduction: float | str
    throughput_retention: float
    min_throughput_retention: float
    min_ppl_degradation_reduction: float
    status: str
    details: dict = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)


def compute_throughput_retention(
    comp_out_tps: float,
    awq_out_tps: float,
) -> float:
    if awq_out_tps <= 0:
        raise ValueError("awq_out_tps must be positive")
    return comp_out_tps / awq_out_tps


def evaluate_acceptance(
    ppl_fp16: float,
    ppl_awq: float,
    ppl_comp: float,
    comp_out_tps: float,
    awq_out_tps: float,
    min_throughput_retention: float = 0.85,
    min_ppl_degradation_reduction: float = 0.02,
    workload_metrics: Optional[dict] = None,
) -> AcceptanceResult:
    d_awq = ppl_delta(ppl_fp16, ppl_awq)
    d_comp = ppl_delta(ppl_fp16, ppl_comp)
    reduction = ppl_degradation_reduction(d_awq, d_comp)
    retention = compute_throughput_retention(comp_out_tps, awq_out_tps)

    ppl_ok = ppl_comp <= ppl_awq
    if isinstance(reduction, str):
        reduction_val = float("inf")
    else:
        reduction_val = reduction
    reduction_ok = reduction_val >= min_ppl_degradation_reduction
    throughput_ok = retention >= min_throughput_retention

    if isinstance(reduction, str):
        status = "INCONCLUSIVE"
    elif ppl_ok and reduction_ok and throughput_ok:
        status = "PASS"
    else:
        status = "FAIL"

    return AcceptanceResult(
        ppl_fp16=ppl_fp16,
        ppl_awq=ppl_awq,
        ppl_comp=ppl_comp,
        d_awq=d_awq,
        d_comp=d_comp,
        ppl_degradation_reduction=reduction,
        throughput_retention=retention,
        min_throughput_retention=min_throughput_retention,
        min_ppl_degradation_reduction=min_ppl_degradation_reduction,
        status=status,
        details=workload_metrics or {},
    )


def save_acceptance(result: AcceptanceResult, path: str | Path) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(result.to_dict(), f, indent=2, ensure_ascii=False, default=str)
