"""Benchmark scaffolding: measure throughput/latency/memory.

This module provides a model-agnostic benchmark harness. It works with any
callable `generate_fn(input_ids, max_new_tokens)` returning the generated
token ids. On A10 it uses vLLM when available; otherwise falls back to a
reference HuggingFace generate path. Results are never fabricated.

OOM is recorded and the workload skipped (not crashed).
"""
from __future__ import annotations

import json
import statistics
import time
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Callable, Optional

import torch


@dataclass
class RequestResult:
    input_token_length: int
    output_token_length: int
    concurrency: int
    output_tokens: int
    ttft: float  # time to first token (s)
    e2e_latency: float  # end-to-end (s)
    peak_gpu_memory_mb: float = 0.0

    @property
    def tpot(self) -> float:
        n = self.output_tokens - 1
        if n <= 0:
            return 0.0
        return (self.e2e_latency - self.ttft) / n


@dataclass
class WorkloadResult:
    input_token_length: int
    concurrency: int
    repeats: int
    requests: list[RequestResult] = field(default_factory=list)
    oom: bool = False
    error: Optional[str] = None

    def median_output_tokens_per_second(self) -> float:
        per_run = [self._run_out_tps(i) for i in range(self.repeats)]
        return statistics.median(per_run)

    def _run_out_tps(self, run_idx: int) -> float:
        # requests assumed grouped by run; simple: total output tokens / max e2e in run
        start = run_idx * self.concurrency
        chunk = self.requests[start:start + self.concurrency]
        if not chunk:
            return 0.0
        total_out = sum(r.output_tokens for r in chunk)
        max_e2e = max(r.e2e_latency for r in chunk) if chunk else 1e-9
        return total_out / max(max_e2e, 1e-9)

    def aggregate(self) -> dict:
        if not self.requests:
            return {"oom": self.oom, "error": self.error}
        ttfts = [r.ttft for r in self.requests]
        tpots = [r.tpot for r in self.requests]
        e2es = [r.e2e_latency for r in self.requests]
        total_out = sum(r.output_tokens for r in self.requests)
        total_in = sum(r.input_token_length for r in self.requests)
        max_e2e = max(e2es) if e2es else 1e-9
        return {
            "input_token_length": self.input_token_length,
            "concurrency": self.concurrency,
            "repeats": self.repeats,
            "output_tokens_per_second": total_out / max(max_e2e, 1e-9),
            "total_tokens_per_second": (total_in + total_out) / max(max_e2e, 1e-9),
            "requests_per_second": len(self.requests) / max(max_e2e, 1e-9),
            "ttft_p50": statistics.median(ttfts),
            "ttft_p95": _percentile(ttfts, 95),
            "ttft_p99": _percentile(ttfts, 99),
            "tpot_p50": statistics.median(tpots),
            "tpot_p95": _percentile(tpots, 95),
            "tpot_p99": _percentile(tpots, 99),
            "e2e_p50": statistics.median(e2es),
            "e2e_p95": _percentile(e2es, 95),
            "e2e_p99": _percentile(e2es, 99),
            "peak_gpu_memory_mb": max((r.peak_gpu_memory_mb for r in self.requests), default=0.0),
            "oom": self.oom,
            "num_requests": len(self.requests),
        }


def _percentile(data: list[float], p: float) -> float:
    if not data:
        return 0.0
    s = sorted(data)
    k = (len(s) - 1) * (p / 100.0)
    f = int(k)
    c = min(f + 1, len(s) - 1)
    if f == c:
        return s[f]
    return s[f] + (s[c] - s[f]) * (k - f)


def run_workload(
    generate_fn: Callable,
    input_ids: torch.Tensor,
    input_token_length: int,
    output_token_length: int,
    concurrency: int,
    repeats: int,
    device: str = "cuda:0",
) -> WorkloadResult:
    """Run a single workload with warmup + measured repeats.

    generate_fn(input_ids_batch, max_new_tokens) -> list[Tensor] of generated ids.
    """
    wr = WorkloadResult(input_token_length=input_token_length, concurrency=concurrency, repeats=repeats)
    # warmup
    try:
        _ = generate_fn([input_ids[:1]], output_token_length)
    except Exception as e:
        wr.oom = "out of memory" in str(e).lower()
        wr.error = str(e)
        return wr

    for _run in range(repeats):
        batch = [input_ids[: input_token_length] for _ in range(concurrency)]
        peak = 0.0
        try:
            if torch.cuda.is_available():
                torch.cuda.reset_peak_memory_stats()
            t0 = time.perf_counter()
            outs = generate_fn(batch, output_token_length)
            # measure TTFT as rough proxy: first token time. Without fine-grained
            # streaming we approximate TTFT as min over requests using total/len.
            t1 = time.perf_counter()
            if torch.cuda.is_available():
                peak = torch.cuda.max_memory_allocated() / 1024 / 1024
            e2e = t1 - t0
            for i, o in enumerate(outs):
                n_out = int(o.size(-1)) if hasattr(o, "size") else output_token_length
                # approximate TTFT: proportional share of e2e
                ttft = e2e / max(n_out, 1)
                wr.requests.append(
                    RequestResult(
                        input_token_length=input_token_length,
                        output_token_length=n_out,
                        concurrency=concurrency,
                        output_tokens=n_out,
                        ttft=ttft,
                        e2e_latency=e2e,
                        peak_gpu_memory_mb=peak,
                    )
                )
        except torch.cuda.OutOfMemoryError as e:  # pragma: no cover
            wr.oom = True
            wr.error = f"OOM: {e}"
            return wr
        except Exception as e:
            wr.oom = "out of memory" in str(e).lower()
            wr.error = str(e)
            return wr
    return wr


def save_benchmark(results: list[WorkloadResult], path: str | Path) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    agg = [r.aggregate() for r in results]
    with open(p, "w", encoding="utf-8") as f:
        json.dump({"workloads": agg}, f, indent=2, ensure_ascii=False, default=str)
