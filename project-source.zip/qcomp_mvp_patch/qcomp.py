
import torch
import torch.nn.functional as F

class QCompAdapter:
    def __init__(self, A, B, alpha=1.0):
        self.A = A
        self.B = B
        self.alpha = alpha

    def __call__(self, x):
        z = F.linear(x, self.B)
        return self.alpha * F.linear(z, self.A)


def fit_qcomp(X, error, rank=8):
    """
    Fit:
        error ~= (X B^T) A^T
    """

    X = X.float()
    error = error.float()

    U, S, Vh = torch.linalg.svd(
        error,
        full_matrices=False
    )

    r = min(rank, S.numel())

    A = U[:, :r] * S[:r].unsqueeze(0)

    # Solve X B^T ~= V
    target = Vh[:r, :].T
    sol = torch.linalg.lstsq(X, target).solution

    B = sol.T

    return QCompAdapter(A, B)
