
QComp MVP patch

Purpose:
First verify whether activation-space compensation improves AWQ PPL.

Do not benchmark yet.

Acceptance for this MVP:
- layer output error decreases
- PPL does not degrade

After success:
add layer selection and A10 benchmark.
